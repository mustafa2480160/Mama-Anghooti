
create type public.app_role as enum ('admin');
create type public.order_status as enum ('pending_payment','payment_processing','paid','confirmed','preparing','ready_for_pickup','out_for_delivery','delivered','completed','cancelled','refund_pending','refunded','expired');
create type public.payment_status as enum ('pending','processing','paid','failed','cancelled','refunded','expired');
create type public.fulfilment_method as enum ('delivery','pickup');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "own roles readable" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

-- First-admin bootstrap: only works while no admin exists
create or replace function public.claim_first_admin()
returns boolean language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  perform pg_advisory_xact_lock(424242);
  if exists (select 1 from public.user_roles where role = 'admin') then return false; end if;
  insert into public.user_roles(user_id, role) values (auth.uid(), 'admin');
  return true;
end $$;
create or replace function public.admin_exists()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where role = 'admin')
$$;
revoke execute on function public.claim_first_admin() from public, anon;
grant execute on function public.claim_first_admin() to authenticated;
grant execute on function public.admin_exists() to anon, authenticated;

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- Categories
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  description text,
  image_url text,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.categories to anon, authenticated;
grant insert, update, delete on public.categories to authenticated;
grant all on public.categories to service_role;
alter table public.categories enable row level security;
create policy "public read active categories" on public.categories for select to anon, authenticated using (is_active or public.has_role(auth.uid(),'admin'));
create policy "admin write categories" on public.categories for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create trigger categories_touch before update on public.categories for each row execute function public.touch_updated_at();

-- Products
create table public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique check (char_length(sku) between 1 and 40),
  name text not null check (char_length(name) between 1 and 140),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  category_id uuid references public.categories(id) on delete set null,
  subcategory text,
  description text not null default '',
  price integer not null check (price >= 0),
  compare_at_price integer check (compare_at_price is null or compare_at_price >= 0),
  stock integer not null default 0 check (stock >= 0),
  sizes text[] not null default '{}',
  colours text[] not null default '{}',
  is_active boolean not null default true,
  is_featured boolean not null default false,
  is_new_arrival boolean not null default false,
  is_sample boolean not null default false,
  sold_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_category_idx on public.products(category_id);
create index products_active_idx on public.products(is_active, created_at desc);
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "public read active products" on public.products for select to anon, authenticated using (is_active or public.has_role(auth.uid(),'admin'));
create policy "admin write products" on public.products for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  url text not null,
  alt text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index product_images_product_idx on public.product_images(product_id, sort_order);
grant select on public.product_images to anon, authenticated;
grant insert, update, delete on public.product_images to authenticated;
grant all on public.product_images to service_role;
alter table public.product_images enable row level security;
create policy "public read images" on public.product_images for select to anon, authenticated using (true);
create policy "admin write images" on public.product_images for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  label text not null check (char_length(label) between 1 and 80),
  size text,
  colour text,
  sku text unique,
  price_adjustment integer not null default 0,
  stock integer not null default 0 check (stock >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index product_variants_product_idx on public.product_variants(product_id);
grant select on public.product_variants to anon, authenticated;
grant insert, update, delete on public.product_variants to authenticated;
grant all on public.product_variants to service_role;
alter table public.product_variants enable row level security;
create policy "public read variants" on public.product_variants for select to anon, authenticated using (is_active or public.has_role(auth.uid(),'admin'));
create policy "admin write variants" on public.product_variants for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create trigger variants_touch before update on public.product_variants for each row execute function public.touch_updated_at();

-- Store & delivery settings (singleton)
create table public.store_settings (
  id int primary key default 1 check (id = 1),
  store_name text not null default 'Mama Anghothi Wala',
  address text not null default '',
  city text not null default 'Karachi',
  latitude double precision,
  longitude double precision,
  phone_primary text not null default '',
  phone_secondary text not null default '',
  whatsapp text not null default '',
  email text not null default '',
  opening_hours text not null default '',
  pickup_instructions text not null default '',
  instagram_url text not null default '',
  facebook_url text not null default '',
  tiktok_url text not null default '',
  delivery_enabled boolean not null default true,
  pickup_enabled boolean not null default true,
  base_fee integer not null default 130 check (base_fee >= 0),
  base_km numeric not null default 10 check (base_km >= 0),
  step_km numeric not null default 10 check (step_km > 0),
  step_fee integer not null default 50 check (step_fee >= 0),
  max_radius_km numeric check (max_radius_km is null or max_radius_km > 0),
  unsupported_areas text[] not null default '{}',
  payment_window_minutes int not null default 30 check (payment_window_minutes between 5 and 1440),
  announcement text not null default '',
  updated_at timestamptz not null default now()
);
grant select on public.store_settings to anon, authenticated;
grant update on public.store_settings to authenticated;
grant all on public.store_settings to service_role;
alter table public.store_settings enable row level security;
create policy "public read settings" on public.store_settings for select to anon, authenticated using (true);
create policy "admin update settings" on public.store_settings for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create trigger settings_touch before update on public.store_settings for each row execute function public.touch_updated_at();

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  image_url text,
  link_url text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
grant select on public.banners to anon, authenticated;
grant insert, update, delete on public.banners to authenticated;
grant all on public.banners to service_role;
alter table public.banners enable row level security;
create policy "public read banners" on public.banners for select to anon, authenticated using (is_active or public.has_role(auth.uid(),'admin'));
create policy "admin write banners" on public.banners for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Customers (guest, keyed by phone)
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique,
  full_name text not null,
  email text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.customers to authenticated;
grant all on public.customers to service_role;
alter table public.customers enable row level security;
create policy "admin read customers" on public.customers for select to authenticated using (public.has_role(auth.uid(),'admin'));

-- Orders
create sequence public.order_number_seq start 1001;
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  access_token text not null unique default encode(extensions.gen_random_bytes(24),'hex'),
  idempotency_key text not null unique,
  customer_id uuid references public.customers(id) on delete set null,
  status order_status not null default 'pending_payment',
  payment_status payment_status not null default 'pending',
  fulfilment fulfilment_method not null,
  customer_name text not null,
  phone text not null,
  email text,
  address text,
  city text,
  area text,
  landmark text,
  notes text,
  distance_km numeric,
  delivery_fee integer not null default 0 check (delivery_fee >= 0),
  subtotal integer not null check (subtotal >= 0),
  total integer not null check (total >= 0),
  stock_reserved boolean not null default true,
  reservation_expires_at timestamptz not null,
  paid_at timestamptz,
  admin_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pickup_no_fee check (fulfilment = 'delivery' or delivery_fee = 0),
  constraint total_matches check (total = subtotal + delivery_fee)
);
create index orders_created_idx on public.orders(created_at desc);
create index orders_status_idx on public.orders(status);
create index orders_phone_idx on public.orders(phone);
grant select, update on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "admin read orders" on public.orders for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin update orders" on public.orders for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create trigger orders_touch before update on public.orders for each row execute function public.touch_updated_at();

-- Paid-state guard: only service role (payment verification) may set paid
create or replace function public.guard_order_payment() returns trigger language plpgsql as $$
begin
  if current_user <> 'service_role' and current_user <> 'postgres' then
    if new.payment_status is distinct from old.payment_status or new.total <> old.total
       or new.delivery_fee <> old.delivery_fee or new.subtotal <> old.subtotal or new.paid_at is distinct from old.paid_at then
      raise exception 'Payment and amount fields can only be changed by verified payment processing';
    end if;
    if old.payment_status <> 'paid' and new.status in ('paid','confirmed','preparing','ready_for_pickup','out_for_delivery','delivered','completed') then
      raise exception 'Order cannot advance before payment is verified';
    end if;
  end if;
  return new;
end $$;
create trigger orders_guard before update on public.orders for each row execute function public.guard_order_payment();

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  product_name text not null,
  sku text not null,
  variant_label text,
  image_url text,
  unit_price integer not null check (unit_price >= 0),
  quantity integer not null check (quantity between 1 and 50),
  line_total integer not null check (line_total >= 0)
);
create index order_items_order_idx on public.order_items(order_id);
grant select on public.order_items to authenticated;
grant all on public.order_items to service_role;
alter table public.order_items enable row level security;
create policy "admin read items" on public.order_items for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  provider text not null default 'safepay',
  environment text not null default 'sandbox',
  tracker text unique,
  reference text,
  status payment_status not null default 'pending',
  amount integer not null,
  currency text not null default 'PKR',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index payments_order_idx on public.payments(order_id);
grant select on public.payments to authenticated;
grant all on public.payments to service_role;
alter table public.payments enable row level security;
create policy "admin read payments" on public.payments for select to authenticated using (public.has_role(auth.uid(),'admin'));
create trigger payments_touch before update on public.payments for each row execute function public.touch_updated_at();

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid references public.payments(id) on delete set null,
  event_key text not null unique,
  event_type text not null,
  source text not null,
  payload jsonb not null default '{}',
  created_at timestamptz not null default now()
);
grant select on public.payment_events to authenticated;
grant all on public.payment_events to service_role;
alter table public.payment_events enable row level security;
create policy "admin read payment events" on public.payment_events for select to authenticated using (public.has_role(auth.uid(),'admin'));

create table public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb not null default '{}',
  created_at timestamptz not null default now()
);
grant select, insert on public.admin_audit_log to authenticated;
grant all on public.admin_audit_log to service_role;
alter table public.admin_audit_log enable row level security;
create policy "admin read audit" on public.admin_audit_log for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin insert audit" on public.admin_audit_log for insert to authenticated with check (public.has_role(auth.uid(),'admin') and user_id = auth.uid());

create table public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  phone text check (phone is null or char_length(phone) <= 20),
  email text check (email is null or char_length(email) <= 200),
  message text not null check (char_length(message) between 1 and 2000),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
grant select, update, delete on public.contact_messages to authenticated;
grant all on public.contact_messages to service_role;
alter table public.contact_messages enable row level security;
create policy "admin manage messages" on public.contact_messages for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Atomic order creation with stock reservation (service role only)
create or replace function public.create_order_reserving_stock(_order jsonb, _items jsonb)
returns table(order_id uuid, order_number text, access_token text, existing boolean)
language plpgsql security definer set search_path = public, extensions as $$
declare
  v_existing public.orders%rowtype;
  v_customer uuid;
  v_order public.orders%rowtype;
  v_item jsonb;
  v_rows int;
begin
  select * into v_existing from public.orders where idempotency_key = _order->>'idempotency_key';
  if found then
    return query select v_existing.id, v_existing.order_number, v_existing.access_token, true; return;
  end if;

  insert into public.customers(phone, full_name, email)
  values (_order->>'phone', _order->>'customer_name', nullif(_order->>'email',''))
  on conflict (phone) do update set full_name = excluded.full_name, email = coalesce(excluded.email, public.customers.email), updated_at = now()
  returning id into v_customer;

  for v_item in select * from jsonb_array_elements(_items) loop
    if (v_item->>'variant_id') is not null then
      update public.product_variants set stock = stock - (v_item->>'quantity')::int
       where id = (v_item->>'variant_id')::uuid and stock >= (v_item->>'quantity')::int and is_active;
    else
      update public.products set stock = stock - (v_item->>'quantity')::int
       where id = (v_item->>'product_id')::uuid and stock >= (v_item->>'quantity')::int and is_active;
    end if;
    get diagnostics v_rows = row_count;
    if v_rows = 0 then
      raise exception 'OUT_OF_STOCK:%', v_item->>'product_name';
    end if;
  end loop;

  insert into public.orders(order_number, idempotency_key, customer_id, fulfilment, customer_name, phone, email,
    address, city, area, landmark, notes, distance_km, delivery_fee, subtotal, total, reservation_expires_at)
  values ('MAW-' || to_char(now(),'YYMM') || '-' || nextval('public.order_number_seq'),
    _order->>'idempotency_key', v_customer, (_order->>'fulfilment')::fulfilment_method,
    _order->>'customer_name', _order->>'phone', nullif(_order->>'email',''),
    nullif(_order->>'address',''), nullif(_order->>'city',''), nullif(_order->>'area',''),
    nullif(_order->>'landmark',''), nullif(_order->>'notes',''),
    nullif(_order->>'distance_km','')::numeric, (_order->>'delivery_fee')::int,
    (_order->>'subtotal')::int, (_order->>'total')::int,
    now() + make_interval(mins => (_order->>'payment_window_minutes')::int))
  returning * into v_order;

  insert into public.order_items(order_id, product_id, variant_id, product_name, sku, variant_label, image_url, unit_price, quantity, line_total)
  select v_order.id, (i->>'product_id')::uuid, nullif(i->>'variant_id','')::uuid, i->>'product_name', i->>'sku',
         nullif(i->>'variant_label',''), nullif(i->>'image_url',''), (i->>'unit_price')::int, (i->>'quantity')::int,
         (i->>'unit_price')::int * (i->>'quantity')::int
  from jsonb_array_elements(_items) i;

  return query select v_order.id, v_order.order_number, v_order.access_token, false;
end $$;

-- Release reserved stock (idempotent)
create or replace function public.release_order_stock(_order_id uuid, _new_status order_status, _new_payment payment_status)
returns void language plpgsql security definer set search_path = public as $$
declare v_order public.orders%rowtype; it record;
begin
  select * into v_order from public.orders where id = _order_id for update;
  if not found or v_order.payment_status = 'paid' then return; end if;
  if v_order.stock_reserved then
    for it in select * from public.order_items where order_id = _order_id loop
      if it.variant_id is not null then
        update public.product_variants set stock = stock + it.quantity where id = it.variant_id;
      elsif it.product_id is not null then
        update public.products set stock = stock + it.quantity where id = it.product_id;
      end if;
    end loop;
  end if;
  update public.orders set stock_reserved = false, status = _new_status, payment_status = _new_payment where id = _order_id;
end $$;

-- Mark paid (idempotent). Re-reserves stock if it had been released.
create or replace function public.mark_order_paid(_order_id uuid, _amount int)
returns text language plpgsql security definer set search_path = public as $$
declare v_order public.orders%rowtype; it record; v_rows int;
begin
  select * into v_order from public.orders where id = _order_id for update;
  if not found then return 'not_found'; end if;
  if v_order.payment_status = 'paid' then return 'already_paid'; end if;
  if _amount <> v_order.total then return 'amount_mismatch'; end if;
  if not v_order.stock_reserved then
    for it in select * from public.order_items where order_id = _order_id loop
      if it.variant_id is not null then
        update public.product_variants set stock = stock - it.quantity where id = it.variant_id and stock >= it.quantity;
      else
        update public.products set stock = stock - it.quantity where id = it.product_id and stock >= it.quantity;
      end if;
      get diagnostics v_rows = row_count;
      if v_rows = 0 then
        update public.orders set payment_status='paid', paid_at=now(), status='refund_pending',
          admin_notes = coalesce(admin_notes,'') || ' Paid after expiry but stock unavailable — refund needed.'
        where id = _order_id;
        return 'paid_no_stock';
      end if;
    end loop;
  end if;
  update public.orders set payment_status='paid', paid_at=now(), status='paid', stock_reserved=true where id=_order_id;
  update public.products p set sold_count = sold_count + oi.quantity from public.order_items oi where oi.order_id=_order_id and oi.product_id=p.id;
  return 'paid';
end $$;

create or replace function public.expire_stale_orders()
returns int language plpgsql security definer set search_path = public as $$
declare r record; n int := 0;
begin
  for r in select id from public.orders where payment_status in ('pending','processing','failed','cancelled') and status in ('pending_payment','payment_processing') and reservation_expires_at < now() loop
    perform public.release_order_stock(r.id, 'expired', 'expired'); n := n + 1;
  end loop;
  return n;
end $$;

revoke execute on function public.create_order_reserving_stock(jsonb,jsonb) from public, anon, authenticated;
revoke execute on function public.release_order_stock(uuid,order_status,payment_status) from public, anon, authenticated;
revoke execute on function public.mark_order_paid(uuid,int) from public, anon, authenticated;
revoke execute on function public.expire_stale_orders() from public, anon;
grant execute on function public.create_order_reserving_stock(jsonb,jsonb) to service_role;
grant execute on function public.release_order_stock(uuid,order_status,payment_status) to service_role;
grant execute on function public.mark_order_paid(uuid,int) to service_role;
grant execute on function public.expire_stale_orders() to service_role, authenticated;

-- Storage policies for product images bucket
create policy "public read product images" on storage.objects for select using (bucket_id = 'product-images');
create policy "admin upload product images" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.has_role(auth.uid(),'admin'));
create policy "admin update product images" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.has_role(auth.uid(),'admin'));
create policy "admin delete product images" on storage.objects for delete to authenticated using (bucket_id = 'product-images' and public.has_role(auth.uid(),'admin'));
