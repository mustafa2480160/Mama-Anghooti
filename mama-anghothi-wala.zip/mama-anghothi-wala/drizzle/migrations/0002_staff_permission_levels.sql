COMMENT ON TYPE public.app_role IS 'admin = Owner (full access), manager = manages staff and catalogue, employee = orders and messages';

CREATE OR REPLACE FUNCTION public.staff_level(_user_id uuid)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(max(CASE role WHEN 'admin' THEN 3 WHEN 'manager' THEN 2 WHEN 'employee' THEN 1 ELSE 0 END), 0)
  FROM public.user_roles WHERE user_id = _user_id
$$;
REVOKE EXECUTE ON FUNCTION public.staff_level(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.staff_level(uuid) TO authenticated;

-- catalogue: manager+
DROP POLICY "public read active categories" ON public.categories;
CREATE POLICY "public read active categories" ON public.categories FOR SELECT TO anon, authenticated USING (is_active OR public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin write categories" ON public.categories;
CREATE POLICY "manager write categories" ON public.categories FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 2) WITH CHECK (public.staff_level(auth.uid()) >= 2);

DROP POLICY "public read active products" ON public.products;
CREATE POLICY "public read active products" ON public.products FOR SELECT TO anon, authenticated USING (is_active OR public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin write products" ON public.products;
CREATE POLICY "manager write products" ON public.products FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 2) WITH CHECK (public.staff_level(auth.uid()) >= 2);

DROP POLICY "admin write images" ON public.product_images;
CREATE POLICY "manager write images" ON public.product_images FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 2) WITH CHECK (public.staff_level(auth.uid()) >= 2);

DROP POLICY "public read variants" ON public.product_variants;
CREATE POLICY "public read variants" ON public.product_variants FOR SELECT TO anon, authenticated USING (is_active OR public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin write variants" ON public.product_variants;
CREATE POLICY "manager write variants" ON public.product_variants FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 2) WITH CHECK (public.staff_level(auth.uid()) >= 2);

DROP POLICY "public read banners" ON public.banners;
CREATE POLICY "public read banners" ON public.banners FOR SELECT TO anon, authenticated USING (is_active OR public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin write banners" ON public.banners;
CREATE POLICY "manager write banners" ON public.banners FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 2) WITH CHECK (public.staff_level(auth.uid()) >= 2);

DROP POLICY "admin upload product images" ON storage.objects;
DROP POLICY "admin update product images" ON storage.objects;
DROP POLICY "admin delete product images" ON storage.objects;
CREATE POLICY "manager upload product images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'product-images' AND public.staff_level(auth.uid()) >= 2);
CREATE POLICY "manager update product images" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'product-images' AND public.staff_level(auth.uid()) >= 2);
CREATE POLICY "manager delete product images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'product-images' AND public.staff_level(auth.uid()) >= 2);

-- orders & messages: employee+
DROP POLICY "admin read customers" ON public.customers;
CREATE POLICY "staff read customers" ON public.customers FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin read orders" ON public.orders;
CREATE POLICY "staff read orders" ON public.orders FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin update orders" ON public.orders;
CREATE POLICY "staff update orders" ON public.orders FOR UPDATE TO authenticated USING (public.staff_level(auth.uid()) >= 1) WITH CHECK (public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin read items" ON public.order_items;
CREATE POLICY "staff read items" ON public.order_items FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin read payments" ON public.payments;
CREATE POLICY "staff read payments" ON public.payments FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 1);
DROP POLICY "admin read payment events" ON public.payment_events;
CREATE POLICY "manager read payment events" ON public.payment_events FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 2);
DROP POLICY "admin manage messages" ON public.contact_messages;
CREATE POLICY "staff manage messages" ON public.contact_messages FOR ALL TO authenticated USING (public.staff_level(auth.uid()) >= 1) WITH CHECK (public.staff_level(auth.uid()) >= 1);

DROP POLICY "admin read audit" ON public.admin_audit_log;
CREATE POLICY "manager read audit" ON public.admin_audit_log FOR SELECT TO authenticated USING (public.staff_level(auth.uid()) >= 2);
DROP POLICY "admin insert audit" ON public.admin_audit_log;
CREATE POLICY "staff insert audit" ON public.admin_audit_log FOR INSERT TO authenticated WITH CHECK (public.staff_level(auth.uid()) >= 1 AND user_id = auth.uid());

DROP POLICY "own roles readable" ON public.user_roles;
CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.staff_level(auth.uid()) >= 2);

-- staff management
CREATE OR REPLACE FUNCTION public.list_staff()
RETURNS TABLE(user_id uuid, email text, role app_role, created_at timestamptz)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF public.staff_level(auth.uid()) < 2 THEN RAISE EXCEPTION 'Not allowed'; END IF;
  RETURN QUERY SELECT r.user_id, u.email::text, r.role, r.created_at
    FROM public.user_roles r JOIN auth.users u ON u.id = r.user_id
    ORDER BY CASE r.role WHEN 'admin' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END, u.email;
END $$;

CREATE OR REPLACE FUNCTION public.set_staff_role(_email text, _role app_role)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE me int := public.staff_level(auth.uid()); target uuid; cur int;
BEGIN
  IF me < 2 THEN RAISE EXCEPTION 'Not allowed'; END IF;
  IF _role = 'admin' THEN RAISE EXCEPTION 'Owner access cannot be given here'; END IF;
  IF me = 2 AND _role <> 'employee' THEN RAISE EXCEPTION 'Managers can only add employees'; END IF;
  SELECT id INTO target FROM auth.users WHERE lower(email) = lower(trim(_email));
  IF target IS NULL THEN RAISE EXCEPTION 'No account with that email. Ask them to create one on the admin login page first.'; END IF;
  IF target = auth.uid() THEN RAISE EXCEPTION 'You cannot change your own access'; END IF;
  cur := public.staff_level(target);
  IF cur >= me THEN RAISE EXCEPTION 'You cannot change this person''s access'; END IF;
  DELETE FROM public.user_roles WHERE user_id = target;
  INSERT INTO public.user_roles(user_id, role) VALUES (target, _role);
  INSERT INTO public.admin_audit_log(user_id, action, entity, entity_id, details)
    VALUES (auth.uid(), 'set_role', 'staff', target::text, jsonb_build_object('role', _role));
  RETURN 'ok';
END $$;

CREATE OR REPLACE FUNCTION public.remove_staff(_user_id uuid)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE me int := public.staff_level(auth.uid());
BEGIN
  IF me < 2 THEN RAISE EXCEPTION 'Not allowed'; END IF;
  IF _user_id = auth.uid() THEN RAISE EXCEPTION 'You cannot remove yourself'; END IF;
  IF public.staff_level(_user_id) >= me THEN RAISE EXCEPTION 'You cannot remove this person'; END IF;
  DELETE FROM public.user_roles WHERE user_id = _user_id;
  INSERT INTO public.admin_audit_log(user_id, action, entity, entity_id) VALUES (auth.uid(), 'remove_role', 'staff', _user_id::text);
  RETURN 'ok';
END $$;

REVOKE EXECUTE ON FUNCTION public.list_staff() FROM public, anon;
REVOKE EXECUTE ON FUNCTION public.set_staff_role(text, app_role) FROM public, anon;
REVOKE EXECUTE ON FUNCTION public.remove_staff(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.list_staff() TO authenticated;
GRANT EXECUTE ON FUNCTION public.set_staff_role(text, app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.remove_staff(uuid) TO authenticated;