ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_method text NOT NULL DEFAULT 'online';
ALTER TABLE public.orders ADD CONSTRAINT orders_payment_method_chk CHECK (payment_method IN ('online','cod'));
ALTER TABLE public.orders ADD CONSTRAINT orders_cod_delivery_only CHECK (payment_method = 'online' OR fulfilment = 'delivery');
ALTER TABLE public.store_settings ADD COLUMN IF NOT EXISTS cod_enabled boolean NOT NULL DEFAULT true;

CREATE OR REPLACE FUNCTION public.guard_order_payment() RETURNS trigger LANGUAGE plpgsql AS $$
begin
  if current_user <> 'service_role' and current_user <> 'postgres' then
    if new.payment_method is distinct from old.payment_method or new.total <> old.total
       or new.delivery_fee <> old.delivery_fee or new.subtotal <> old.subtotal then
      raise exception 'Payment and amount fields can only be changed by verified payment processing';
    end if;
    if new.payment_status is distinct from old.payment_status then
      -- Staff may record cash collected for cash-on-delivery orders only.
      if not (old.payment_method = 'cod' and old.payment_status = 'pending' and new.payment_status = 'paid') then
        raise exception 'Payment and amount fields can only be changed by verified payment processing';
      end if;
      new.paid_at := now();
    elsif new.paid_at is distinct from old.paid_at then
      raise exception 'Payment and amount fields can only be changed by verified payment processing';
    end if;
    if old.payment_method = 'online' and old.payment_status <> 'paid'
       and new.status in ('paid','confirmed','preparing','ready_for_pickup','out_for_delivery','delivered','completed') then
      raise exception 'Order cannot advance before payment is verified';
    end if;
  end if;
  return new;
end $$;