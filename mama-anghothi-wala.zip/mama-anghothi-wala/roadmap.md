# Roadmap — Mama Anghothi Wala

- [x] Database schema, security rules, image storage, sample data
- [x] Design system with a bold Gen-Z feel
- [x] Storefront: home, shop, a full page for every category, product page, search
- [x] Cart (saved across refresh)
- [x] Checkout page (delivery/pickup), payment page, order confirmation, order lookup
- [x] Delivery information page + other info/policy pages
- [x] Admin login + dashboard: add/remove items, change pictures, update prices, stock, orders, settings
- [ ] Tests, README, verification
