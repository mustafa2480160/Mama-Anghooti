import type { ReactNode } from "react";

export function InfoPage({ kicker, title, children }: { kicker: string; title: string; children: ReactNode }) {
  return (
    <div className="container-shop max-w-3xl py-12 md:py-16">
      <p className="font-serif text-lg italic text-primary">{kicker}</p>
      <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">{title}</h1>
      <div className="prose-shop mt-8">{children}</div>
    </div>
  );
}

export const infoHead = (title: string, description: string) => () => ({
  meta: [
    { title: `${title} — Mama Anghothi Wala` },
    { name: "description", content: description },
    { property: "og:title", content: `${title} — Mama Anghothi Wala` },
    { property: "og:description", content: description },
  ],
});
