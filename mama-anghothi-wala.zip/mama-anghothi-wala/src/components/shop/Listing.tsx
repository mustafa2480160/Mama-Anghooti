import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ProductGrid } from "./ProductCard";
import { Button } from "@/components/ui/button";
import { productsQuery } from "@/lib/queries";
import { PAGE_SIZE, type ListParams } from "@/lib/catalog.functions";
import { z } from "zod";

export const listSearchSchema = z.object({
  q: z.string().max(100).optional().catch(undefined),
  sort: z.enum(["new", "price_asc", "price_desc", "popular"]).optional().catch(undefined),
  min: z.coerce.number().int().min(0).optional().catch(undefined),
  max: z.coerce.number().int().min(0).optional().catch(undefined),
  page: z.coerce.number().int().min(1).optional().catch(undefined),
  inStock: z.coerce.boolean().optional().catch(undefined),
});
export type ListSearch = z.infer<typeof listSearchSchema>;

export function Listing({
  title,
  kicker,
  description,
  category,
  search,
  showSearchBox = false,
}: {
  title: string;
  kicker?: string;
  description?: string | null | undefined;
  category?: string;
  search: ListSearch;
  showSearchBox?: boolean;
}) {
  const navigate = useNavigate();
  const params: ListParams = { ...search, category };
  const { data, isLoading, isError, refetch } = useQuery(productsQuery(params));
  const [min, setMin] = useState(search.min?.toString() ?? "");
  const [max, setMax] = useState(search.max?.toString() ?? "");
  const [q, setQ] = useState(search.q ?? "");
  useEffect(() => setQ(search.q ?? ""), [search.q]);

  const set = (patch: Partial<ListSearch>) =>
    navigate({ to: ".", search: (prev: ListSearch) => ({ ...prev, page: undefined, ...patch }), replace: true });

  const pages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;
  const field = "h-11 rounded-full border border-input bg-card px-4 text-sm outline-none focus:border-primary";

  return (
    <div className="container-shop py-10 md:py-14">
      <header className="mb-8">
        {kicker && <p className="font-serif text-lg italic text-primary">{kicker}</p>}
        <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">{title}</h1>
        {description && <p className="mt-2 max-w-xl text-muted-foreground">{description}</p>}
      </header>

      {showSearchBox && (
        <form
          role="search"
          className="mb-6 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            set({ q: q.trim() || undefined });
          }}
        >
          <label className="flex-1">
            <span className="sr-only">Search</span>
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search rings, chains, jhumkas…" className={`${field} w-full`} />
          </label>
          <Button type="submit" variant="pop">Search</Button>
        </form>
      )}

      <div className="mb-8 flex flex-wrap items-center gap-2 rounded-3xl bg-secondary/60 p-3">
        <label className="flex items-center gap-2 text-sm">
          <span className="font-medium">Sort</span>
          <select className={field} value={search.sort ?? "new"} onChange={(e) => set({ sort: e.target.value as ListSearch["sort"] })}>
            <option value="new">Newest</option>
            <option value="popular">Popular</option>
            <option value="price_asc">Price: low → high</option>
            <option value="price_desc">Price: high → low</option>
          </select>
        </label>
        <form
          className="flex items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            set({ min: min ? Number(min) : undefined, max: max ? Number(max) : undefined });
          }}
        >
          <input aria-label="Minimum price" inputMode="numeric" placeholder="Min Rs." value={min} onChange={(e) => setMin(e.target.value.replace(/\D/g, ""))} className={`${field} w-24`} />
          <span aria-hidden>–</span>
          <input aria-label="Maximum price" inputMode="numeric" placeholder="Max Rs." value={max} onChange={(e) => setMax(e.target.value.replace(/\D/g, ""))} className={`${field} w-24`} />
          <Button type="submit" size="sm" variant="outline">Apply</Button>
        </form>
        <label className="flex items-center gap-2 px-2 text-sm font-medium">
          <input type="checkbox" className="size-4 accent-primary" checked={!!search.inStock} onChange={(e) => set({ inStock: e.target.checked || undefined })} />
          In stock only
        </label>
        {data && <span className="ml-auto px-2 text-sm text-muted-foreground">{data.total} item{data.total === 1 ? "" : "s"}</span>}
      </div>

      {isLoading && (
        <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-[3/4] animate-pulse rounded-3xl bg-muted" />
          ))}
        </div>
      )}
      {isError && (
        <div className="rounded-3xl border p-10 text-center">
          <p>Couldn't load products.</p>
          <Button className="mt-4" onClick={() => refetch()}>Try again</Button>
        </div>
      )}
      {data && data.items.length === 0 && (
        <div className="rounded-3xl border-2 border-dashed p-12 text-center">
          <p className="font-display text-2xl font-bold">Nothing here (yet) 👀</p>
          <p className="mt-2 text-muted-foreground">Try a different search or clear the filters.</p>
          <Button className="mt-4" variant="outline" onClick={() => navigate({ to: ".", search: {} })}>Clear filters</Button>
        </div>
      )}
      {data && data.items.length > 0 && <ProductGrid items={data.items} />}

      {pages > 1 && (
        <nav className="mt-10 flex items-center justify-center gap-2" aria-label="Pagination">
          <Button variant="outline" size="sm" disabled={(search.page ?? 1) <= 1} onClick={() => set({ page: (search.page ?? 1) - 1 })}>Previous</Button>
          <span className="px-3 text-sm">Page {search.page ?? 1} of {pages}</span>
          <Button variant="outline" size="sm" disabled={(search.page ?? 1) >= pages} onClick={() => set({ page: (search.page ?? 1) + 1 })}>Next</Button>
        </nav>
      )}
    </div>
  );
}
