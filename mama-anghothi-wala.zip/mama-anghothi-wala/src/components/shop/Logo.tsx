import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({ className, light = false }: { className?: string; light?: boolean }) {
  return (
    <Link to="/" className={cn("group inline-flex items-center gap-2", className)} aria-label="Mama Anghothi Wala — home">
      <span
        aria-hidden
        className="grid size-9 place-items-center rounded-full bg-gold-shine font-serif text-xl italic text-gold-foreground shadow-pop transition-transform group-hover:rotate-12"
      >
        m
      </span>
      <span className="leading-none">
        <span className={cn("block font-display text-lg font-extrabold tracking-tight", light ? "text-ivory" : "text-primary")}>
          Mama Anghothi
        </span>
        <span className={cn("block font-serif text-sm italic", light ? "text-gold" : "text-muted-foreground")}>wala ✦ karachi</span>
      </span>
    </Link>
  );
}
