import { useQuery } from "@tanstack/react-query";
import { MapPin, Store, Truck } from "lucide-react";
import { imgUrl, PAYMENT_LABEL, rs, STATUS_LABEL } from "@/lib/format";
import { storeInfoQuery } from "@/lib/queries";
import { cn } from "@/lib/utils";

export interface OrderView {
  order_number: string;
  status: string;
  payment_status: string;
  payment_method?: string;
  fulfilment: string;
  customer_name: string;
  phone: string;
  address: string | null;
  area: string | null;
  city: string | null;
  landmark: string | null;
  distance_km: number | null;
  delivery_fee: number;
  subtotal: number;
  total: number;
  reservation_expires_at: string;
  created_at: string;
  order_items: { product_name: string; variant_label: string | null; image_url: string | null; unit_price: number; quantity: number; line_total: number }[];
}

export function OrderDetails({ o }: { o: OrderView }) {
  const { data: info } = useQuery(storeInfoQuery);
  const paid = o.payment_status === "paid";
  const s = info?.settings;
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-6">
        <div className="flex flex-wrap gap-2">
          <span className={cn("sticker", paid ? "bg-success text-background" : "bg-gold text-gold-foreground")}>{o.payment_method === "cod" && !paid ? "Cash on delivery" : PAYMENT_LABEL[o.payment_status] ?? o.payment_status}</span>
          <span className="sticker bg-secondary text-secondary-foreground">{STATUS_LABEL[o.status] ?? o.status}</span>
          <span className="sticker bg-muted text-foreground">{o.fulfilment === "pickup" ? "Store pickup" : "Home delivery"}</span>
        </div>
        <ul className="divide-y rounded-3xl border bg-card">
          {o.order_items.map((it, i) => (
            <li key={i} className="flex gap-3 p-4 text-sm">
              <img src={imgUrl(it.image_url)} alt="" className="size-16 rounded-xl object-cover" />
              <div className="flex-1">
                <p className="font-semibold">{it.product_name}</p>
                <p className="text-muted-foreground">{it.variant_label ? `${it.variant_label} · ` : ""}{it.quantity} × {rs(it.unit_price)}</p>
              </div>
              <span className="font-semibold">{rs(it.line_total)}</span>
            </li>
          ))}
        </ul>
        {o.fulfilment === "pickup" ? (
          <div className="rounded-3xl bg-blush/60 p-5 text-sm">
            <p className="flex items-center gap-2 font-display text-lg font-bold"><Store className="size-5" /> Pickup details</p>
            {s && (
              <>
                <p className="mt-2 flex gap-2"><MapPin className="size-4 shrink-0" />{s.address}, {s.city}</p>
                <p className="mt-1">Hours: {s.opening_hours}</p>
                <p className="mt-2 text-muted-foreground">{s.pickup_instructions}</p>
              </>
            )}
            <p className="mt-2 font-semibold">Reference: {o.order_number}</p>
          </div>
        ) : (
          <div className="rounded-3xl bg-secondary/60 p-5 text-sm">
            <p className="flex items-center gap-2 font-display text-lg font-bold"><Truck className="size-5" /> Delivery details</p>
            <p className="mt-2">{o.customer_name} · {o.phone}</p>
            <p>{o.address}, {o.area}, {o.city}</p>
            {o.landmark && <p className="text-muted-foreground">Landmark: {o.landmark}</p>}
            {o.distance_km != null && <p className="text-muted-foreground">Road distance: {o.distance_km} km</p>}
          </div>
        )}
      </div>
      <aside className="h-fit rounded-3xl border-2 border-maroon-deep bg-card p-6 shadow-pop">
        <p className="text-sm text-muted-foreground">Order number</p>
        <p className="font-display text-2xl font-extrabold">{o.order_number}</p>
        <p className="text-xs text-muted-foreground">Placed {new Date(o.created_at).toLocaleString("en-PK")}</p>
        <dl className="mt-4 space-y-2 border-t pt-4 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{rs(o.subtotal)}</dd></div>
          <div className="flex justify-between"><dt>{o.fulfilment === "pickup" ? "Pickup" : "Delivery"}</dt><dd>{o.delivery_fee === 0 ? "Free" : rs(o.delivery_fee)}</dd></div>
          <div className="flex justify-between border-t pt-3 font-display text-lg font-extrabold"><dt>{paid ? "Total paid" : o.payment_method === "cod" ? "Pay rider on delivery" : "Total due"}</dt><dd className="text-primary">{rs(o.total)}</dd></div>
        </dl>
      </aside>
    </div>
  );
}
