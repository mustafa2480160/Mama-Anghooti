import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { imgUrl, rs } from "@/lib/format";
import { totalStock, type PublicProduct } from "@/lib/catalog.functions";

export function ProductCard({ p }: { p: PublicProduct }) {
  const { add } = useCart();
  const stock = totalStock(p);
  const hasVariants = p.product_variants.length > 0;
  const off = p.compare_at_price && p.compare_at_price > p.price ? Math.round((1 - p.price / p.compare_at_price) * 100) : 0;
  const img = p.product_images[0];

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl border border-border bg-card transition-all hover:-translate-y-1 hover:shadow-card">
      <Link to="/product/$slug" params={{ slug: p.slug }} className="relative block aspect-square overflow-hidden bg-muted">
        <img
          src={imgUrl(img?.url)}
          alt={img?.alt ?? p.name}
          loading="lazy"
          width={600}
          height={600}
          className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {off > 0 && <span className="sticker -rotate-3 bg-primary text-primary-foreground">-{off}%</span>}
          {p.is_new_arrival && <span className="sticker rotate-2 bg-gold text-gold-foreground">New drop</span>}
          {p.is_sample && <span className="sticker bg-foreground/80 text-background">Sample</span>}
        </div>
        {stock === 0 && (
          <div className="absolute inset-0 grid place-items-center bg-background/60 backdrop-blur-[2px]">
            <span className="sticker bg-foreground text-background">Sold out</span>
          </div>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        {p.category && <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{p.category.name}</p>}
        <h3 className="line-clamp-2 font-display text-base font-bold leading-snug">
          <Link to="/product/$slug" params={{ slug: p.slug }} className="hover:text-primary">
            {p.name}
          </Link>
        </h3>
        <div className="mt-auto flex items-end justify-between gap-2 pt-1">
          <div>
            <span className="font-display text-lg font-extrabold text-primary">{rs(p.price)}</span>
            {off > 0 && <span className="ml-2 text-sm text-muted-foreground line-through">{rs(p.compare_at_price!)}</span>}
            <p className="text-xs text-muted-foreground">{stock === 0 ? "Out of stock" : stock <= 3 ? `Only ${stock} left!` : "In stock"}</p>
          </div>
          {hasVariants ? (
            <Button asChild size="sm" variant="outline" disabled={stock === 0}>
              <Link to="/product/$slug" params={{ slug: p.slug }}>Options</Link>
            </Button>
          ) : (
            <Button
              size="icon"
              variant="pop"
              disabled={stock === 0}
              aria-label={`Add ${p.name} to cart`}
              onClick={() => {
                add({
                  productId: p.id,
                  variantId: null,
                  slug: p.slug,
                  name: p.name,
                  variantLabel: null,
                  image: img?.url ?? null,
                  unitPrice: p.price,
                  quantity: 1,
                  maxStock: stock,
                });
                toast.success("Added to bag ✨", { description: p.name });
              }}
            >
              <ShoppingBag />
            </Button>
          )}
        </div>
      </div>
    </article>
  );
}

export function ProductGrid({ items }: { items: PublicProduct[] }) {
  return (
    <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">
      {items.map((p) => (
        <ProductCard key={p.id} p={p} />
      ))}
    </div>
  );
}
