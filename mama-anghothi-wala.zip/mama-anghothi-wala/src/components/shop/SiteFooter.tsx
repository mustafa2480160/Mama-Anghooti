import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Clock, MapPin, MessageCircle, Phone } from "lucide-react";
import { Logo } from "./Logo";
import { storeInfoQuery } from "@/lib/queries";

export function SiteFooter() {
  const { data } = useQuery(storeInfoQuery);
  const s = data?.settings;
  const socials = [
    ["Instagram", s?.instagram_url],
    ["Facebook", s?.facebook_url],
    ["TikTok", s?.tiktok_url],
  ].filter(([, u]) => u) as [string, string][];

  return (
    <footer className="mt-24 bg-maroon-deep text-ivory">
      <div className="container-shop py-14">
        <p className="font-display text-4xl font-extrabold leading-none tracking-tight sm:text-6xl md:text-7xl">
          stack it. <span className="font-serif font-normal italic text-gold-shine">flaunt it.</span>
        </p>
        <div className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <Logo light />
            <p className="text-sm text-ivory/70">Artificial & fashion jewellery from Bolton Market, Karachi.</p>
            {socials.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {socials.map(([n, u]) => (
                  <a key={n} href={u} target="_blank" rel="noopener noreferrer" className="rounded-full border border-ivory/30 px-3 py-1.5 text-xs hover:bg-ivory hover:text-primary">
                    {n}
                  </a>
                ))}
              </div>
            )}
          </div>
          <div>
            <h2 className="mb-3 font-display text-sm font-bold uppercase tracking-wider text-gold">Visit the store</h2>
            <ul className="space-y-2.5 text-sm text-ivory/80">
              <li className="flex gap-2"><MapPin className="mt-0.5 size-4 shrink-0" />{s?.address}, {s?.city}</li>
              <li className="flex gap-2"><Clock className="mt-0.5 size-4 shrink-0" />{s?.opening_hours}</li>
              {s?.phone_primary && <li className="flex gap-2"><Phone className="mt-0.5 size-4 shrink-0" /><a href={`tel:${s.phone_primary.replace(/-/g, "")}`} className="hover:text-gold">{s.phone_primary}</a>{s.phone_secondary && <> · <a href={`tel:${s.phone_secondary.replace(/-/g, "")}`} className="hover:text-gold">{s.phone_secondary}</a></>}</li>}
              {s?.whatsapp && <li className="flex gap-2"><MessageCircle className="mt-0.5 size-4 shrink-0" /><a href={`https://wa.me/${s.whatsapp}`} target="_blank" rel="noopener noreferrer" className="hover:text-gold">Chat on WhatsApp</a></li>}
            </ul>
          </div>
          <div>
            <h2 className="mb-3 font-display text-sm font-bold uppercase tracking-wider text-gold">Help</h2>
            <ul className="space-y-2 text-sm text-ivory/80">
              <li><Link to="/track-order" className="hover:text-gold">Track your order</Link></li>
              <li><Link to="/faq" className="hover:text-gold">FAQ</Link></li>
              <li><Link to="/contact" className="hover:text-gold">Contact us</Link></li>
              <li><Link to="/about" className="hover:text-gold">About us</Link></li>
            </ul>
          </div>
          <div>
            <h2 className="mb-3 font-display text-sm font-bold uppercase tracking-wider text-gold">Policies</h2>
            <ul className="space-y-2 text-sm text-ivory/80">
              <li><Link to="/shipping-policy" className="hover:text-gold">Shipping & delivery</Link></li>
              <li><Link to="/pickup-policy" className="hover:text-gold">Store pickup</Link></li>
              <li><Link to="/returns-policy" className="hover:text-gold">Returns & refunds</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-gold">Privacy policy</Link></li>
              <li><Link to="/terms" className="hover:text-gold">Terms & conditions</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-2 border-t border-ivory/15 pt-6 text-xs text-ivory/60 sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} Mama Anghothi Wala. All prices in PKR.</p>
          <p>Secure online payments · No cash on delivery</p>
        </div>
      </div>
    </footer>
  );
}
