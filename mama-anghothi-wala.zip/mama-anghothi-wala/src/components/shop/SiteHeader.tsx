import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Menu, Search, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { Logo } from "./Logo";
import { useCart } from "@/lib/cart";
import { storeInfoQuery } from "@/lib/queries";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export function SiteHeader() {
  const { data } = useQuery(storeInfoQuery);
  const { count, hydrated } = useCart();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const cats = data?.categories ?? [];

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) navigate({ to: "/search", search: { q: q.trim() } });
  };

  return (
    <header className="sticky top-0 z-40">
      {data?.settings.announcement && (
        <div className="overflow-hidden bg-maroon-deep py-2 text-xs font-medium text-ivory">
          <div className="flex w-max animate-marquee gap-12 whitespace-nowrap">
            {Array.from({ length: 6 }).map((_, i) => (
              <span key={i} className="flex items-center gap-12">
                <span>✦ {data.settings.announcement}</span>
                <span className="text-gold">✦ 100% online payment · no cash on delivery</span>
              </span>
            ))}
          </div>
        </div>
      )}
      <div className="border-b border-border bg-background/85 backdrop-blur-md">
        <div className="container-shop flex h-16 items-center gap-3 md:h-20">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger className="grid size-11 place-items-center rounded-full hover:bg-secondary lg:hidden" aria-label="Open menu">
              <Menu className="size-5" />
            </SheetTrigger>
            <SheetContent side="left" className="w-[85vw] max-w-sm bg-background">
              <SheetTitle className="sr-only">Menu</SheetTitle>
              <nav className="mt-8 flex flex-col gap-1" aria-label="Mobile">
                <Link to="/shop" onClick={() => setOpen(false)} className="rounded-xl px-3 py-3 font-display text-2xl font-bold hover:bg-secondary">
                  Shop all
                </Link>
                {cats.map((c) => (
                  <Link
                    key={c.slug}
                    to="/category/$slug"
                    params={{ slug: c.slug }}
                    onClick={() => setOpen(false)}
                    className="rounded-xl px-3 py-3 font-display text-2xl font-bold hover:bg-secondary"
                  >
                    {c.name}
                  </Link>
                ))}
                <hr className="my-3" />
                {([
                  ["/track-order", "Track order"],
                  ["/about", "About us"],
                  ["/contact", "Contact"],
                  ["/faq", "FAQ"],
                ] as const).map(([to, label]) => (
                  <Link key={to} to={to} onClick={() => setOpen(false)} className="rounded-xl px-3 py-2 text-muted-foreground hover:bg-secondary">
                    {label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>

          <Logo />

          <nav className="ml-6 hidden items-center gap-1 lg:flex" aria-label="Main">
            <Link to="/shop" className="rounded-full px-3 py-2 text-sm font-semibold hover:bg-secondary" activeProps={{ className: "bg-secondary text-primary" }}>
              Shop all
            </Link>
            {cats.map((c) => (
              <Link
                key={c.slug}
                to="/category/$slug"
                params={{ slug: c.slug }}
                className="rounded-full px-3 py-2 text-sm font-semibold hover:bg-secondary"
                activeProps={{ className: "bg-secondary text-primary" }}
              >
                {c.name}
              </Link>
            ))}
          </nav>

          <form onSubmit={submit} role="search" className="ml-auto hidden md:block">
            <label className="relative block">
              <span className="sr-only">Search jewellery</span>
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search rings, chains…"
                className="h-11 w-44 rounded-full border border-input bg-card pl-9 pr-3 text-sm outline-none focus:border-primary xl:w-60"
              />
            </label>
          </form>

          <Link
            to="/search"
            search={{ q: "" }}
            className="ml-auto grid size-11 place-items-center rounded-full hover:bg-secondary md:hidden"
            aria-label="Search"
          >
            <Search className="size-5" />
          </Link>

          <Link to="/cart" className="relative grid size-11 place-items-center rounded-full bg-primary text-primary-foreground transition-transform hover:scale-105" aria-label={`Bag, ${count} items`}>
            <ShoppingBag className="size-5" />
            {hydrated && count > 0 && (
              <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-gold text-[10px] font-bold text-gold-foreground">
                {count}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}

