import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export interface CartItem {
  productId: string;
  variantId: string | null;
  slug: string;
  name: string;
  variantLabel: string | null;
  image: string | null;
  unitPrice: number;
  quantity: number;
  maxStock: number;
}

interface CartCtx {
  items: CartItem[];
  count: number;
  subtotal: number;
  hydrated: boolean;
  add: (item: CartItem) => void;
  setQty: (productId: string, variantId: string | null, qty: number) => void;
  remove: (productId: string, variantId: string | null) => void;
  replace: (items: CartItem[]) => void;
  clear: () => void;
}

const KEY = "maw-cart-v1";
const Ctx = createContext<CartCtx | null>(null);
const same = (a: CartItem, id: string, v: string | null) => a.productId === id && a.variantId === v;

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setItems(parsed.filter((i) => i && typeof i.productId === "string"));
      }
    } catch {
      /* ignore corrupt cart */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(KEY, JSON.stringify(items));
  }, [items, hydrated]);

  const add = useCallback((item: CartItem) => {
    setItems((prev) => {
      const ex = prev.find((p) => same(p, item.productId, item.variantId));
      if (ex) {
        return prev.map((p) =>
          same(p, item.productId, item.variantId)
            ? { ...p, ...item, quantity: Math.min(item.maxStock, p.quantity + item.quantity) }
            : p,
        );
      }
      return [...prev, { ...item, quantity: Math.min(item.maxStock, item.quantity) }];
    });
  }, []);

  const setQty = useCallback((id: string, v: string | null, qty: number) => {
    setItems((prev) =>
      prev.map((p) => (same(p, id, v) ? { ...p, quantity: Math.max(1, Math.min(p.maxStock, qty)) } : p)),
    );
  }, []);

  const remove = useCallback((id: string, v: string | null) => {
    setItems((prev) => prev.filter((p) => !same(p, id, v)));
  }, []);

  const value = useMemo<CartCtx>(
    () => ({
      items,
      hydrated,
      count: items.reduce((s, i) => s + i.quantity, 0),
      subtotal: items.reduce((s, i) => s + i.quantity * i.unitPrice, 0),
      add,
      setQty,
      remove,
      replace: setItems,
      clear: () => setItems([]),
    }),
    [items, hydrated, add, setQty, remove],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
