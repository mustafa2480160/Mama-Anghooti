import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// Public catalog reads. Only active products/categories and public columns are returned.
const PRODUCT_COLS =
  "id, sku, name, slug, subcategory, description, price, compare_at_price, stock, sizes, colours, is_featured, is_new_arrival, is_sample, sold_count, created_at, category:categories(name, slug), product_images(url, alt, sort_order), product_variants(id, label, size, colour, price_adjustment, stock, is_active)";

export type PublicProduct = {
  id: string;
  sku: string;
  name: string;
  slug: string;
  subcategory: string | null;
  description: string;
  price: number;
  compare_at_price: number | null;
  stock: number;
  sizes: string[];
  colours: string[];
  is_featured: boolean;
  is_new_arrival: boolean;
  is_sample: boolean;
  sold_count: number;
  created_at: string;
  category: { name: string; slug: string } | null;
  product_images: { url: string; alt: string | null; sort_order: number }[];
  product_variants: { id: string; label: string; size: string | null; colour: string | null; price_adjustment: number; stock: number; is_active: boolean }[];
};

export function totalStock(p: PublicProduct) {
  const v = p.product_variants.filter((x) => x.is_active);
  return v.length ? v.reduce((s, x) => s + x.stock, 0) : p.stock;
}

function tidy(p: PublicProduct): PublicProduct {
  return {
    ...p,
    product_images: [...p.product_images].sort((a, b) => a.sort_order - b.sort_order),
    product_variants: p.product_variants.filter((v) => v.is_active),
  };
}

export const getStoreInfo = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const [{ data: s }, { data: cats }] = await Promise.all([
    supabaseAdmin
      .from("store_settings")
      .select(
        "store_name, address, city, phone_primary, phone_secondary, whatsapp, email, opening_hours, pickup_instructions, instagram_url, facebook_url, tiktok_url, delivery_enabled, pickup_enabled, cod_enabled, base_fee, base_km, step_km, step_fee, max_radius_km, payment_window_minutes, announcement",
      )
      .eq("id", 1)
      .single(),
    supabaseAdmin.from("categories").select("id, name, slug, description, image_url").eq("is_active", true).order("sort_order"),
  ]);
  return { settings: s!, categories: cats ?? [] };
});

const listSchema = z.object({
  category: z.string().max(80).optional(),
  q: z.string().max(100).optional(),
  min: z.number().int().min(0).optional(),
  max: z.number().int().min(0).optional(),
  sort: z.enum(["new", "price_asc", "price_desc", "popular"]).optional(),
  page: z.number().int().min(1).max(500).optional(),
  inStock: z.boolean().optional(),
});
export type ListParams = z.infer<typeof listSchema>;
export const PAGE_SIZE = 12;

export const listProducts = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => listSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const page = data.page ?? 1;
    let catId: string | null = null;
    if (data.category) {
      const { data: c } = await supabaseAdmin.from("categories").select("id").eq("slug", data.category).eq("is_active", true).maybeSingle();
      if (!c) return { items: [] as PublicProduct[], total: 0, page };
      catId = c.id;
    }
    let q = supabaseAdmin.from("products").select(PRODUCT_COLS, { count: "exact" }).eq("is_active", true);
    if (catId) q = q.eq("category_id", catId);
    if (data.q) {
      const term = data.q.replace(/[%_,()]/g, " ").trim();
      if (term) q = q.or(`name.ilike.%${term}%,description.ilike.%${term}%,sku.ilike.%${term}%,subcategory.ilike.%${term}%`);
    }
    if (data.min != null) q = q.gte("price", data.min);
    if (data.max != null) q = q.lte("price", data.max);
    if (data.inStock) q = q.gt("stock", 0);
    switch (data.sort) {
      case "price_asc": q = q.order("price", { ascending: true }); break;
      case "price_desc": q = q.order("price", { ascending: false }); break;
      case "popular": q = q.order("sold_count", { ascending: false }); break;
      default: q = q.order("created_at", { ascending: false });
    }
    const from = (page - 1) * PAGE_SIZE;
    const { data: rows, count, error } = await q.range(from, from + PAGE_SIZE - 1);
    if (error) throw new Error("Could not load products");
    return { items: (rows as unknown as PublicProduct[]).map(tidy), total: count ?? 0, page };
  });

export const getHome = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const base = () => supabaseAdmin.from("products").select(PRODUCT_COLS).eq("is_active", true);
  const [f, n, b, banners] = await Promise.all([
    base().eq("is_featured", true).order("created_at", { ascending: false }).limit(8),
    base().eq("is_new_arrival", true).order("created_at", { ascending: false }).limit(8),
    base().gt("sold_count", 0).order("sold_count", { ascending: false }).limit(4),
    supabaseAdmin.from("banners").select("id, title, subtitle, image_url, link_url").eq("is_active", true).order("sort_order").limit(3),
  ]);
  const map = (r: { data: unknown }) => ((r.data ?? []) as PublicProduct[]).map(tidy);
  return { featured: map(f), newArrivals: map(n), bestSellers: map(b), banners: banners.data ?? [] };
});

export const getProduct = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ slug: z.string().max(100) }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: p } = await supabaseAdmin
      .from("products")
      .select(PRODUCT_COLS + ", category_id")
      .eq("slug", data.slug)
      .eq("is_active", true)
      .maybeSingle();
    if (!p) return null;
    const prod = tidy(p as unknown as PublicProduct);
    const catId = (p as unknown as { category_id: string | null }).category_id;
    let related: PublicProduct[] = [];
    if (catId) {
      const { data: r } = await supabaseAdmin
        .from("products")
        .select(PRODUCT_COLS)
        .eq("is_active", true)
        .eq("category_id", catId)
        .neq("id", prod.id)
        .limit(4);
      related = ((r ?? []) as unknown as PublicProduct[]).map(tidy);
    }
    return { product: prod, related };
  });
