import { describe, it, expect } from "vitest";
import { deliveryFee } from "./delivery";

describe("deliveryFee", () => {
  it("0 km costs Rs. 130", () => expect(deliveryFee(0)).toBe(130));
  it("exactly 10 km costs Rs. 130", () => expect(deliveryFee(10)).toBe(130));
  it("just over 10 km costs Rs. 180", () => expect(deliveryFee(10.1)).toBe(180));
  it("exactly 20 km costs Rs. 180", () => expect(deliveryFee(20)).toBe(180));
  it("just over 20 km costs Rs. 230", () => expect(deliveryFee(20.01)).toBe(230));
  it("30 km costs Rs. 230", () => expect(deliveryFee(30)).toBe(230));
  it("35 km costs Rs. 280", () => expect(deliveryFee(35)).toBe(280));
  it("rejects negative distance", () => expect(() => deliveryFee(-1)).toThrow());
  it("uses configured pricing", () =>
    expect(deliveryFee(25, { base_fee: 100, base_km: 5, step_km: 5, step_fee: 20 })).toBe(180));
});
