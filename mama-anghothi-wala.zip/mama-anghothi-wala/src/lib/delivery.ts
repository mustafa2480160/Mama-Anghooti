export interface DeliveryPricing {
  base_fee: number;
  base_km: number;
  step_km: number;
  step_fee: number;
}

export const DEFAULT_PRICING: DeliveryPricing = { base_fee: 130, base_km: 10, step_km: 10, step_fee: 50 };

/** Delivery charge = base + stepFee × ceil(max(0, km − baseKm) / stepKm). Pickup is always 0. */
export function deliveryFee(distanceKm: number, p: DeliveryPricing = DEFAULT_PRICING): number {
  if (!Number.isFinite(distanceKm) || distanceKm < 0) throw new Error("Invalid distance");
  // round to metres to avoid floating-point noise (e.g. 10.0000001)
  const km = Math.round(distanceKm * 1000) / 1000;
  const extra = Math.max(0, km - Number(p.base_km));
  const steps = Math.ceil(extra / Number(p.step_km));
  return Number(p.base_fee) + Number(p.step_fee) * steps;
}
