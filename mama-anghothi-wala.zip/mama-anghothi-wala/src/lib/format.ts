export const rs = (n: number) => `Rs. ${Math.round(n).toLocaleString("en-PK")}`;

/** Resolve a stored image reference to a browser URL. Storage paths are served via our image route. */
export function imgUrl(u?: string | null): string {
  if (!u) return "/images/cat-others.jpg";
  if (u.startsWith("/") || u.startsWith("http")) return u;
  return `/api/public/img/${u.split("/").map(encodeURIComponent).join("/")}`;
}

export const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);

export const STATUS_LABEL: Record<string, string> = {
  pending_payment: "Pending Payment",
  payment_processing: "Payment Processing",
  paid: "Paid",
  confirmed: "Confirmed",
  preparing: "Preparing",
  ready_for_pickup: "Ready for Pickup",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  completed: "Completed",
  cancelled: "Cancelled",
  refund_pending: "Refund Pending",
  refunded: "Refunded",
  expired: "Expired (unpaid)",
};

export const PAYMENT_LABEL: Record<string, string> = {
  pending: "Awaiting payment",
  processing: "Processing",
  paid: "Paid (verified)",
  failed: "Failed",
  cancelled: "Cancelled",
  refunded: "Refunded",
  expired: "Expired",
};

/** Statuses an admin may move an order to, given fulfilment + payment. */
export function allowedNextStatuses(fulfilment: string, paid: boolean): string[] {
  if (!paid) return ["pending_payment", "cancelled"];
  const common = ["paid", "confirmed", "preparing"];
  const path =
    fulfilment === "pickup" ? ["ready_for_pickup", "completed"] : ["out_for_delivery", "delivered", "completed"];
  return [...common, ...path, "cancelled", "refund_pending", "refunded"];
}
