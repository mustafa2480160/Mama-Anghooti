import { queryOptions } from "@tanstack/react-query";
import { getHome, getProduct, getStoreInfo, listProducts, type ListParams } from "./catalog.functions";

export const storeInfoQuery = queryOptions({
  queryKey: ["store-info"],
  queryFn: () => getStoreInfo(),
  staleTime: 60_000,
});
export const homeQuery = queryOptions({ queryKey: ["home"], queryFn: () => getHome(), staleTime: 30_000 });
export const productsQuery = (p: ListParams) =>
  queryOptions({ queryKey: ["products", p], queryFn: () => listProducts({ data: p }), staleTime: 30_000 });
export const productQuery = (slug: string) =>
  queryOptions({ queryKey: ["product", slug], queryFn: () => getProduct({ data: { slug } }), staleTime: 30_000 });
