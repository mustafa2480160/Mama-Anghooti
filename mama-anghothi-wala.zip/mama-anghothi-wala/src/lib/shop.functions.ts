import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";

const phoneRe = /^(\+92|0092|0)?3\d{9}$/;
const normPhone = (p: string) => {
  const d = p.replace(/[\s-]/g, "");
  return "0" + d.replace(/^(\+92|0092|0)/, "");
};
const token = z.string().regex(/^[a-f0-9]{48}$/);
const line = z.object({
  productId: z.string().uuid(),
  variantId: z.string().uuid().nullable(),
  quantity: z.number().int().min(1).max(50),
});
const addr = z.object({
  address: z.string().trim().min(8, "Please enter your full address").max(300),
  area: z.string().trim().min(2, "Please enter your area").max(100),
  city: z.string().trim().min(2).max(60),
});

async function friendly<T>(fn: () => Promise<T>): Promise<{ ok: true; data: T } | { ok: false; error: string }> {
  const { UserError } = await import("@/server/shop.server");
  try {
    return { ok: true, data: await fn() };
  } catch (e) {
    if (e instanceof UserError) return { ok: false, error: e.message };
    console.error(e);
    return { ok: false, error: "Something went wrong on our side. Please try again." };
  }
}

function originOf() {
  const req = getRequest();
  const url = new URL(req.url);
  const proto = req.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? url.host;
  return `${proto}://${host}`;
}

export const validateCart = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ items: z.array(line).max(50) }).parse(d))
  .handler(async ({ data }) => {
    const { priceCart } = await import("@/server/shop.server");
    if (data.items.length === 0) return [];
    return priceCart(data.items);
  });

export const getDeliveryQuote = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => addr.parse(d))
  .handler(async ({ data }) => {
    const { quoteDelivery } = await import("@/server/shop.server");
    return friendly(() => quoteDelivery(data));
  });

const checkoutSchema = z
  .object({
    idempotencyKey: z.string().uuid(),
    items: z.array(line).min(1).max(50),
    fulfilment: z.enum(["delivery", "pickup"]),
    paymentMethod: z.enum(["online", "cod"]).default("online"),
    customer: z.object({
      name: z.string().trim().min(2).max(100),
      phone: z.string().trim().regex(phoneRe, "Enter a valid Pakistani mobile number"),
      email: z.string().trim().email().max(200).optional().or(z.literal("")),
      address: z.string().trim().max(300).optional(),
      city: z.string().trim().max(60).optional(),
      area: z.string().trim().max(100).optional(),
      landmark: z.string().trim().max(150).optional(),
      notes: z.string().trim().max(500).optional(),
    }),
    website: z.string().max(0).optional(), // honeypot
  })
  .superRefine((v, ctx) => {
    if (v.paymentMethod === "cod" && v.fulfilment !== "delivery") ctx.addIssue({ code: "custom", message: "Pickup orders must be paid online", path: ["paymentMethod"] });
    if (v.fulfilment === "delivery") {
      const r = addr.safeParse({ address: v.customer.address, area: v.customer.area, city: v.customer.city });
      if (!r.success) ctx.addIssue({ code: "custom", message: r.error.issues[0]?.message ?? "Invalid address", path: ["customer", "address"] });
    }
  });

export const placeOrder = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => checkoutSchema.parse(d))
  .handler(async ({ data }) => {
    const { createOrderAndPayment } = await import("@/server/shop.server");
    return friendly(() =>
      createOrderAndPayment({
        idempotencyKey: data.idempotencyKey,
        items: data.items,
        fulfilment: data.fulfilment,
        paymentMethod: data.paymentMethod,
        customer: { ...data.customer, phone: normPhone(data.customer.phone), ...(data.customer.email ? { email: data.customer.email } : {}) } as never,
        origin: originOf(),
      }),
    );
  });

export const retryPayment = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ token }).parse(d))
  .handler(async ({ data }) => {
    const { startPayment, UserError } = await import("@/server/shop.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: o } = await supabaseAdmin.from("orders").select("id").eq("access_token", data.token).maybeSingle();
    if (!o) return { ok: false as const, error: "Order not found." };
    try {
      return { ok: true as const, data: await startPayment(o.id, originOf()) };
    } catch (e) {
      return { ok: false as const, error: e instanceof UserError ? e.message : "Payment could not be started. Please try again." };
    }
  });

/** Called when the customer returns from Safepay. Verifies server-to-server; ignores browser claims. */
export const verifyOrderPayment = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ token, cancelled: z.boolean().optional() }).parse(d))
  .handler(async ({ data }) => {
    const { settlePayment, orderByToken } = await import("@/server/shop.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: o } = await supabaseAdmin
      .from("orders")
      .select("id, payment_status")
      .eq("access_token", data.token)
      .maybeSingle();
    if (!o) return null;
    if (o.payment_status !== "paid") {
      const { data: pay } = await supabaseAdmin
        .from("payments")
        .select("id")
        .eq("order_id", o.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (pay) {
        const r = await settlePayment(pay.id);
        if (data.cancelled && (r === "pending" || r === "unknown")) {
          await supabaseAdmin.from("payments").update({ status: "cancelled" }).eq("id", pay.id).neq("status", "paid");
          await supabaseAdmin
            .from("orders")
            .update({ status: "pending_payment", payment_status: "cancelled" })
            .eq("id", o.id)
            .neq("payment_status", "paid");
        }
      }
    }
    return orderByToken(data.token);
  });

export const getOrder = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ token }).parse(d))
  .handler(async ({ data }) => {
    const { orderByToken } = await import("@/server/shop.server");
    return orderByToken(data.token);
  });

export const lookupOrder = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ orderNumber: z.string().trim().min(5).max(30), phone: z.string().trim().regex(phoneRe) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: o } = await supabaseAdmin
      .from("orders")
      .select("access_token")
      .eq("order_number", data.orderNumber.toUpperCase())
      .eq("phone", normPhone(data.phone))
      .maybeSingle();
    return o ? { token: o.access_token } : null;
  });

export const sendContactMessage = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z
      .object({
        name: z.string().trim().min(2).max(100),
        phone: z.string().trim().max(20).optional(),
        email: z.string().trim().email().max(200).optional().or(z.literal("")),
        message: z.string().trim().min(5).max(2000),
        website: z.string().max(0).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("contact_messages").insert({
      name: data.name,
      phone: data.phone || null,
      email: data.email || null,
      message: data.message,
    });
    return { ok: !error };
  });
