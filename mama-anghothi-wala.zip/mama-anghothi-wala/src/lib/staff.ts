import { redirect } from "@tanstack/react-router";

/** 3 = Owner, 2 = Manager, 1 = Employee. Mirrors public.staff_level() in the database, which enforces it. */
export const LEVEL_LABEL: Record<number, string> = { 3: "Owner", 2: "Manager", 1: "Employee" };
export const ROLE_LABEL = { admin: "Owner", manager: "Manager", employee: "Employee" } as const;

export function canAssign(myLevel: number): ("manager" | "employee")[] {
  if (myLevel >= 3) return ["manager", "employee"];
  if (myLevel === 2) return ["employee"];
  return [];
}

export function requireLevel(level: number | undefined, min: number) {
  if ((level ?? 0) < min) throw redirect({ to: "/admin" });
}
