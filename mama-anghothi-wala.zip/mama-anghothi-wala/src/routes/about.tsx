import { createFileRoute, Link } from "@tanstack/react-router";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: infoHead("About Us", "Mama Anghothi Wala — artificial and fashion jewellery from Bolton Market, Karachi."),
  component: () => (
    <InfoPage kicker="hey, it's us" title="About Mama Anghothi Wala">
      <p>We're an artificial and fashion jewellery shop based in Bolton Market, Karachi — known for our anghothiyan (rings), plus chains, bracelets, necklaces, bands and more.</p>
      <p>Our goal is simple: trendy pieces at fair prices, shown honestly, and an easy way to order online — with delivery across Karachi or free pickup from the store.</p>
      <div className="not-prose mt-8"><Button asChild variant="pop"><Link to="/shop">Shop the collection</Link></Button></div>
    </InfoPage>
  ),
});
