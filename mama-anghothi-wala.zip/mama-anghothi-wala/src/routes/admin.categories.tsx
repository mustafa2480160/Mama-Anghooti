import { requireLevel } from "@/lib/staff";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { imgUrl, slugify } from "@/lib/format";
import { uploadImage } from "@/lib/admin-upload";

export const Route = createFileRoute("/admin/categories")({ beforeLoad: ({ context }) => requireLevel(context.level, 2), component: Categories });

function Categories() {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const { data } = useQuery({
    queryKey: ["admin", "categories"],
    queryFn: async () => (await supabase.from("categories").select("*").order("sort_order")).data ?? [],
  });
  const refresh = () => qc.invalidateQueries();
  const upd = async (id: string, patch: { name?: string; is_active?: boolean; image_url?: string }) => {
    const { error } = await supabase.from("categories").update(patch).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Saved"); refresh(); }
  };
  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    const { error } = await supabase.from("categories").insert({ name: name.trim(), slug: slugify(name), sort_order: (data?.length ?? 0) + 1 });
    if (error) return void toast.error(error.message.includes("duplicate") ? "A category with that name already exists." : error.message);
    setName(""); refresh();
  }
  async function pic(id: string, file?: File) {
    if (!file) return;
    try { await upd(id, { image_url: await uploadImage(file, "categories") }); } catch (e) { toast.error((e as Error).message); }
  }
  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="font-display text-3xl font-bold">Categories</h1>
      <form onSubmit={add} className="flex gap-2"><Input placeholder="New category name" value={name} onChange={(e) => setName(e.target.value)} /><Button type="submit">Add</Button></form>
      <div className="space-y-3">
        {data?.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center gap-4 rounded-2xl border bg-card p-4">
            <img src={imgUrl(c.image_url)} alt="" className="h-16 w-16 rounded-xl object-cover" />
            <Input defaultValue={c.name} className="max-w-xs" onBlur={(e) => e.target.value.trim() && e.target.value !== c.name && upd(c.id, { name: e.target.value.trim() })} />
            <label className="cursor-pointer text-sm underline">Change picture<input type="file" accept="image/*" className="hidden" onChange={(e) => pic(c.id, e.target.files?.[0])} /></label>
            <label className="ml-auto flex items-center gap-2 text-sm"><Switch checked={c.is_active} onCheckedChange={(v) => upd(c.id, { is_active: v })} /> Visible</label>
          </div>
        ))}
      </div>
    </div>
  );
}
