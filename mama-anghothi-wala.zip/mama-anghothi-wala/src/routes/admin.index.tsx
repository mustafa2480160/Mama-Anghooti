import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { rs, STATUS_LABEL } from "@/lib/format";

export const Route = createFileRoute("/admin/")({ component: Overview });

function Overview() {
  const { data } = useQuery({
    queryKey: ["admin", "overview"],
    queryFn: async () => {
      const start = new Date(); start.setHours(0, 0, 0, 0);
      const [today, paid, low, recent, unread] = await Promise.all([
        supabase.from("orders").select("id", { count: "exact", head: true }).gte("created_at", start.toISOString()),
        supabase.from("orders").select("total").eq("payment_status", "paid"),
        supabase.from("products").select("id, name, stock").lte("stock", 3).eq("is_active", true).order("stock").limit(10),
        supabase.from("orders").select("id, order_number, customer_name, total, status, created_at").order("created_at", { ascending: false }).limit(8),
        supabase.from("contact_messages").select("id", { count: "exact", head: true }).eq("is_read", false),
      ]);
      return {
        today: today.count ?? 0,
        paidCount: paid.data?.length ?? 0,
        revenue: (paid.data ?? []).reduce((s, o) => s + o.total, 0),
        low: low.data ?? [],
        recent: recent.data ?? [],
        unread: unread.count ?? 0,
      };
    },
  });
  const stat = (label: string, v: string | number) => (
    <div className="rounded-2xl border bg-card p-5"><p className="text-sm text-muted-foreground">{label}</p><p className="mt-1 font-display text-3xl font-bold">{v}</p></div>
  );
  return (
    <div className="space-y-8">
      <h1 className="font-display text-3xl font-bold">Overview</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stat("Orders today", data?.today ?? "…")}
        {stat("Paid orders", data?.paidCount ?? "…")}
        {stat("Paid sales", data ? rs(data.revenue) : "…")}
        {stat("Unread messages", data?.unread ?? "…")}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border bg-card p-5">
          <h2 className="font-semibold">Recent orders</h2>
          <ul className="mt-3 divide-y text-sm">
            {data?.recent.map((o) => (
              <li key={o.id} className="flex justify-between py-2">
                <span>{o.order_number} · {o.customer_name}</span>
                <span>{rs(o.total)} · {STATUS_LABEL[o.status] ?? o.status}</span>
              </li>
            ))}
            {data && data.recent.length === 0 && <li className="py-2 text-muted-foreground">No orders yet.</li>}
          </ul>
          <Link to="/admin/orders" className="mt-3 inline-block text-sm text-primary underline">All orders</Link>
        </section>
        <section className="rounded-2xl border bg-card p-5">
          <h2 className="font-semibold">Low stock (3 or fewer)</h2>
          <ul className="mt-3 divide-y text-sm">
            {data?.low.map((p) => (
              <li key={p.id} className="flex justify-between py-2">
                <Link to="/admin/products/$id" params={{ id: p.id }} className="hover:underline">{p.name}</Link>
                <span className={p.stock === 0 ? "font-semibold text-destructive" : ""}>{p.stock} left</span>
              </li>
            ))}
            {data && data.low.length === 0 && <li className="py-2 text-muted-foreground">All good.</li>}
          </ul>
        </section>
      </div>
    </div>
  );
}
