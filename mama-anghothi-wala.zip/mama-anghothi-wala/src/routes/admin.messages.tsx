import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/admin/messages")({ component: Messages });

function Messages() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin", "messages"],
    queryFn: async () => (await supabase.from("contact_messages").select("*").order("created_at", { ascending: false })).data ?? [],
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin"] });
  return (
    <div className="max-w-3xl space-y-4">
      <h1 className="font-display text-3xl font-bold">Messages</h1>
      {data?.length === 0 && <p className="text-muted-foreground">No messages yet.</p>}
      {data?.map((m) => (
        <div key={m.id} className={`rounded-2xl border bg-card p-4 ${m.is_read ? "opacity-70" : ""}`}>
          <div className="flex flex-wrap justify-between gap-2 text-sm">
            <b>{m.name}</b>
            <span>{[m.phone, m.email].filter(Boolean).join(" · ")}</span>
            <span className="text-muted-foreground">{new Date(m.created_at).toLocaleString("en-PK")}</span>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-sm">{m.message}</p>
          <div className="mt-3 flex gap-2">
            {!m.is_read && <Button size="sm" variant="outline" onClick={async () => { await supabase.from("contact_messages").update({ is_read: true }).eq("id", m.id); refresh(); }}>Mark read</Button>}
            <Button size="sm" variant="ghost" onClick={async () => { if (confirm("Delete message?")) { await supabase.from("contact_messages").delete().eq("id", m.id); refresh(); } }}>Delete</Button>
          </div>
        </div>
      ))}
    </div>
  );
}
