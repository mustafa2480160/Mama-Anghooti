import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { rs, STATUS_LABEL } from "@/lib/format";

type Status = Database["public"]["Enums"]["order_status"];
export const Route = createFileRoute("/admin/orders")({ component: Orders });

const NEXT: Status[] = ["confirmed", "preparing", "ready_for_pickup", "out_for_delivery", "delivered", "completed", "cancelled"];

function Orders() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"all" | "paid" | "unpaid">("paid");
  const [open, setOpen] = useState<string | null>(null);
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "orders", filter],
    queryFn: async () => {
      let q = supabase.from("orders").select("*, order_items(product_name, variant_label, quantity, unit_price, line_total)").order("created_at", { ascending: false }).limit(200);
      if (filter === "paid") q = q.eq("payment_status", "paid");
      if (filter === "unpaid") q = q.neq("payment_status", "paid");
      const { data, error } = await q;
      if (error) throw error;
      return data;
    },
  });
  async function setStatus(id: string, status: Status) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Status updated"); qc.invalidateQueries({ queryKey: ["admin"] }); }
  }
  async function markCashReceived(id: string) {
    if (!confirm("Confirm the full cash amount was collected?")) return;
    const { error } = await supabase.from("orders").update({ payment_status: "paid" }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Cash recorded"); qc.invalidateQueries({ queryKey: ["admin"] }); }
  }
  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl font-bold">Orders</h1>
      <div className="flex gap-2 text-sm">
        {(["paid", "unpaid", "all"] as const).map((k) => (
          <button key={k} onClick={() => setFilter(k)} className={`rounded-full border px-4 py-1 ${filter === k ? "bg-primary text-primary-foreground" : "bg-card"}`}>
            {k === "paid" ? "Paid" : k === "unpaid" ? "Not paid" : "All"}
          </button>
        ))}
      </div>
      {isLoading && <p>Loading…</p>}
      <div className="space-y-3">
        {data?.map((o) => (
          <div key={o.id} className="rounded-2xl border bg-card p-4">
            <button className="flex w-full flex-wrap items-center justify-between gap-2 text-left" onClick={() => setOpen(open === o.id ? null : o.id)}>
              <span className="font-semibold">{o.order_number}</span>
              <span className="text-sm">{o.customer_name} · {o.phone}</span>
              <span className="text-sm">{o.fulfilment === "pickup" ? "Pickup" : "Delivery"}</span>
              <span className="text-sm font-semibold">{rs(o.total)}</span>
              <span className="rounded-full bg-secondary px-3 py-0.5 text-xs">{STATUS_LABEL[o.status] ?? o.status}</span>
              <span className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("en-PK")}</span>
            </button>
            {open === o.id && (
              <div className="mt-4 grid gap-4 border-t pt-4 text-sm md:grid-cols-2">
                <div className="space-y-1">
                  <p><b>Payment:</b> {o.payment_method === "cod" ? "Cash on delivery" : "Online"} · {o.payment_status}</p>
                  {o.payment_method === "cod" && o.payment_status === "pending" && (
                    <button onClick={() => markCashReceived(o.id)} className="mt-1 rounded-full border px-3 py-1 text-xs hover:bg-secondary">Mark cash received</button>
                  )}
                  {o.email && <p><b>Email:</b> {o.email}</p>}
                  {o.fulfilment === "delivery" && <p><b>Address:</b> {o.address}, {o.area}, {o.city}{o.landmark ? ` (near ${o.landmark})` : ""} · {o.distance_km} km</p>}
                  {o.notes && <p><b>Notes:</b> {o.notes}</p>}
                  <p><b>Subtotal:</b> {rs(o.subtotal)} · <b>Delivery:</b> {rs(o.delivery_fee)}</p>
                </div>
                <div>
                  <ul className="space-y-1">{o.order_items.map((it, i) => <li key={i}>{it.quantity} × {it.product_name}{it.variant_label ? ` (${it.variant_label})` : ""} — {rs(it.line_total)}</li>)}</ul>
                  {(o.payment_status === "paid" || o.payment_method === "cod") && o.status !== "cancelled" && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {NEXT.map((s) => (
                        <button key={s} disabled={o.status === s} onClick={() => setStatus(o.id, s)} className="rounded-full border px-3 py-1 text-xs hover:bg-secondary disabled:bg-primary disabled:text-primary-foreground">
                          {STATUS_LABEL[s] ?? s}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
        {data && data.length === 0 && <p className="text-muted-foreground">No orders here yet.</p>}
      </div>
    </div>
  );
}
