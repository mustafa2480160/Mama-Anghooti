import { requireLevel } from "@/lib/staff";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { imgUrl, slugify } from "@/lib/format";
import { uploadImage } from "@/lib/admin-upload";

export const Route = createFileRoute("/admin/products/$id")({ beforeLoad: ({ context }) => requireLevel(context.level, 2), component: EditProduct });

type Form = {
  name: string; sku: string; description: string; category_id: string; price: string; compare_at_price: string;
  stock: string; is_active: boolean; is_featured: boolean; is_new_arrival: boolean;
};
const empty: Form = { name: "", sku: "", description: "", category_id: "", price: "", compare_at_price: "", stock: "0", is_active: true, is_featured: false, is_new_arrival: true };
type Variant = { id?: string; label: string; price_adjustment: string; stock: string; is_active: boolean };

function EditProduct() {
  const { id } = Route.useParams();
  const isNew = id === "new";
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [f, setF] = useState<Form>(empty);
  const [variants, setVariants] = useState<Variant[]>([]);
  const [saving, setSaving] = useState(false);

  const cats = useQuery({
    queryKey: ["admin", "cats"],
    queryFn: async () => (await supabase.from("categories").select("id, name").order("sort_order")).data ?? [],
  });
  const prod = useQuery({
    queryKey: ["admin", "product", id],
    enabled: !isNew,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*, product_images(id, url, sort_order), product_variants(id, label, price_adjustment, stock, is_active)")
        .eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    const p = prod.data;
    if (!p) return;
    setF({
      name: p.name, sku: p.sku, description: p.description, category_id: p.category_id ?? "", price: String(p.price),
      compare_at_price: p.compare_at_price == null ? "" : String(p.compare_at_price), stock: String(p.stock),
      is_active: p.is_active, is_featured: p.is_featured, is_new_arrival: p.is_new_arrival,
    });
    setVariants(p.product_variants.map((v) => ({ id: v.id, label: v.label, price_adjustment: String(v.price_adjustment), stock: String(v.stock), is_active: v.is_active })));
  }, [prod.data]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((s) => ({ ...s, [k]: v }));
  const images = [...(prod.data?.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order);
  const refresh = () => { qc.invalidateQueries({ queryKey: ["admin"] }); qc.invalidateQueries(); };

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const price = Math.round(Number(f.price));
    const stock = Math.round(Number(f.stock));
    const compare = f.compare_at_price ? Math.round(Number(f.compare_at_price)) : null;
    if (!f.name.trim()) return void toast.error("Name is required.");
    if (!Number.isFinite(price) || price <= 0) return void toast.error("Price must be more than 0.");
    if (!Number.isFinite(stock) || stock < 0) return void toast.error("Stock can't be negative.");
    if (compare != null && compare <= price) return void toast.error("Original price must be higher than the selling price.");
    setSaving(true);
    const row = {
      name: f.name.trim(), sku: f.sku.trim() || `MAW-${Date.now().toString(36).toUpperCase()}`, description: f.description,
      category_id: f.category_id || null, price, compare_at_price: compare, stock,
      is_active: f.is_active, is_featured: f.is_featured, is_new_arrival: f.is_new_arrival,
    };
    try {
      let pid = id;
      if (isNew) {
        const { data, error } = await supabase.from("products")
          .insert({ ...row, slug: `${slugify(row.name)}-${Math.random().toString(36).slice(2, 6)}` }).select("id").single();
        if (error) throw error;
        pid = data.id;
      } else {
        const { error } = await supabase.from("products").update(row).eq("id", id);
        if (error) throw error;
      }
      // variants
      const keep = variants.filter((v) => v.label.trim());
      const existing = prod.data?.product_variants.map((v) => v.id) ?? [];
      const removed = existing.filter((x) => !keep.some((v) => v.id === x));
      if (removed.length) await supabase.from("product_variants").delete().in("id", removed);
      for (const v of keep) {
        const vr = { product_id: pid, label: v.label.trim(), price_adjustment: Math.round(Number(v.price_adjustment) || 0), stock: Math.max(0, Math.round(Number(v.stock) || 0)), is_active: v.is_active };
        const { error } = v.id ? await supabase.from("product_variants").update(vr).eq("id", v.id) : await supabase.from("product_variants").insert(vr);
        if (error) throw error;
      }
      toast.success("Saved");
      refresh();
      if (isNew) navigate({ to: "/admin/products/$id", params: { id: pid }, replace: true });
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function addImages(files: FileList | null) {
    if (!files || isNew) return;
    try {
      let order = images.length;
      for (const file of Array.from(files)) {
        const path = await uploadImage(file, `products/${id}`);
        const { error } = await supabase.from("product_images").insert({ product_id: id, url: path, sort_order: order++, alt: f.name });
        if (error) throw error;
      }
      toast.success("Picture added");
      refresh();
    } catch (err) { toast.error((err as Error).message); }
  }
  async function removeImage(imgId: string, url: string) {
    await supabase.from("product_images").delete().eq("id", imgId);
    if (!url.startsWith("/") && !url.startsWith("http")) await supabase.storage.from("product-images").remove([url]);
    refresh();
  }
  async function makeMain(imgId: string) {
    const ordered = [images.find((i) => i.id === imgId)!, ...images.filter((i) => i.id !== imgId)];
    await Promise.all(ordered.map((im, i) => supabase.from("product_images").update({ sort_order: i }).eq("id", im.id)));
    refresh();
  }
  async function del() {
    if (!confirm("Delete this product permanently? Past orders keep their details. Consider hiding it instead.")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return void toast.error("Couldn't delete — it may be linked to orders. Hide it instead.");
    toast.success("Deleted");
    qc.invalidateQueries();
    navigate({ to: "/admin/products" });
  }

  if (!isNew && prod.isLoading) return <p>Loading…</p>;

  return (
    <div className="max-w-3xl space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-bold">{isNew ? "Add product" : "Edit product"}</h1>
        <Link to="/admin/products" className="text-sm underline">← All products</Link>
      </div>

      <form onSubmit={save} className="space-y-5 rounded-2xl border bg-card p-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2"><Label>Name</Label><Input value={f.name} onChange={(e) => set("name", e.target.value)} required maxLength={120} /></div>
          <div><Label>SKU (code)</Label><Input value={f.sku} onChange={(e) => set("sku", e.target.value)} placeholder="Auto if empty" /></div>
          <div><Label>Category</Label>
            <select className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={f.category_id} onChange={(e) => set("category_id", e.target.value)}>
              <option value="">— None —</option>
              {cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div><Label>Price (Rs.)</Label><Input type="number" min={1} value={f.price} onChange={(e) => set("price", e.target.value)} required /></div>
          <div><Label>Original price (Rs., optional, shows as sale)</Label><Input type="number" min={1} value={f.compare_at_price} onChange={(e) => set("compare_at_price", e.target.value)} /></div>
          <div><Label>Stock</Label><Input type="number" min={0} value={f.stock} onChange={(e) => set("stock", e.target.value)} /></div>
          <div className="sm:col-span-2"><Label>Description</Label><Textarea rows={4} value={f.description} onChange={(e) => set("description", e.target.value)} /></div>
        </div>
        <div className="flex flex-wrap gap-6 text-sm">
          <label className="flex items-center gap-2"><Switch checked={f.is_active} onCheckedChange={(v) => set("is_active", v)} /> Visible in shop</label>
          <label className="flex items-center gap-2"><Switch checked={f.is_featured} onCheckedChange={(v) => set("is_featured", v)} /> Featured</label>
          <label className="flex items-center gap-2"><Switch checked={f.is_new_arrival} onCheckedChange={(v) => set("is_new_arrival", v)} /> New arrival</label>
        </div>

        <div>
          <h2 className="font-semibold">Options (sizes / colours)</h2>
          <p className="text-xs text-muted-foreground">If you add options, customers must pick one and each option has its own stock.</p>
          <div className="mt-3 space-y-2">
            {variants.map((v, i) => (
              <div key={i} className="grid grid-cols-[1fr_7rem_6rem_auto_auto] items-center gap-2">
                <Input placeholder="e.g. Size 7" value={v.label} onChange={(e) => setVariants((s) => s.map((x, j) => j === i ? { ...x, label: e.target.value } : x))} />
                <Input type="number" placeholder="+Rs." value={v.price_adjustment} onChange={(e) => setVariants((s) => s.map((x, j) => j === i ? { ...x, price_adjustment: e.target.value } : x))} />
                <Input type="number" min={0} placeholder="Stock" value={v.stock} onChange={(e) => setVariants((s) => s.map((x, j) => j === i ? { ...x, stock: e.target.value } : x))} />
                <Switch checked={v.is_active} onCheckedChange={(c) => setVariants((s) => s.map((x, j) => j === i ? { ...x, is_active: c } : x))} />
                <Button type="button" size="sm" variant="ghost" onClick={() => setVariants((s) => s.filter((_, j) => j !== i))}>✕</Button>
              </div>
            ))}
            <Button type="button" size="sm" variant="outline" onClick={() => setVariants((s) => [...s, { label: "", price_adjustment: "0", stock: "0", is_active: true }])}>+ Add option</Button>
          </div>
        </div>

        <div className="flex gap-3">
          <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
          {!isNew && <Button type="button" variant="destructive" onClick={del}>Delete</Button>}
        </div>
      </form>

      <section className="rounded-2xl border bg-card p-6">
        <h2 className="font-semibold">Pictures</h2>
        {isNew ? <p className="mt-2 text-sm text-muted-foreground">Save the product first, then add pictures.</p> : (
          <>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {images.map((im, i) => (
                <div key={im.id} className="space-y-2">
                  <img src={imgUrl(im.url)} alt="" className="aspect-square w-full rounded-xl object-cover" />
                  <div className="flex gap-1">
                    {i === 0 ? <span className="text-xs font-semibold text-primary">Main picture</span> : <Button size="sm" variant="outline" onClick={() => makeMain(im.id)}>Make main</Button>}
                    <Button size="sm" variant="ghost" onClick={() => removeImage(im.id, im.url)}>Remove</Button>
                  </div>
                </div>
              ))}
            </div>
            <label className="mt-4 inline-block cursor-pointer rounded-full border px-4 py-2 text-sm font-medium hover:bg-secondary">
              + Upload pictures
              <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { addImages(e.target.files); e.target.value = ""; }} />
            </label>
          </>
        )}
      </section>
    </div>
  );
}
