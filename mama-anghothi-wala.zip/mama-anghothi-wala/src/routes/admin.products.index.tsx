import { requireLevel } from "@/lib/staff";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { imgUrl, rs } from "@/lib/format";

export const Route = createFileRoute("/admin/products/")({ beforeLoad: ({ context }) => requireLevel(context.level, 2), component: Products });

function Products() {
  const [q, setQ] = useState("");
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin", "products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("id, name, sku, price, stock, is_active, categories(name), product_images(url, sort_order)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  const list = (data ?? []).filter((p) => `${p.name} ${p.sku}`.toLowerCase().includes(q.toLowerCase()));

  async function toggle(id: string, v: boolean) {
    const { error } = await supabase.from("products").update({ is_active: v }).eq("id", id);
    if (error) toast.error(error.message); else { toast.success(v ? "Now visible in shop" : "Hidden from shop"); qc.invalidateQueries({ queryKey: ["admin", "products"] }); }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-3xl font-bold">Products</h1>
        <Button asChild><Link to="/admin/products/$id" params={{ id: "new" }}>+ Add product</Link></Button>
      </div>
      <Input placeholder="Search by name or SKU" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />
      {isLoading && <p>Loading…</p>}
      <div className="overflow-x-auto rounded-2xl border bg-card">
        <table className="w-full text-sm">
          <thead className="border-b text-left text-muted-foreground"><tr><th className="p-3">Item</th><th className="p-3">Category</th><th className="p-3">Price</th><th className="p-3">Stock</th><th className="p-3">Visible</th><th /></tr></thead>
          <tbody>
            {list.map((p) => {
              const img = [...p.product_images].sort((a, b) => a.sort_order - b.sort_order)[0]?.url;
              return (
                <tr key={p.id} className="border-b last:border-0">
                  <td className="p-3"><div className="flex items-center gap-3"><img src={imgUrl(img)} alt="" className="h-12 w-12 rounded-lg object-cover" /><div><p className="font-medium">{p.name}</p><p className="text-xs text-muted-foreground">{p.sku}</p></div></div></td>
                  <td className="p-3">{p.categories?.name ?? "—"}</td>
                  <td className="p-3">{rs(p.price)}</td>
                  <td className={`p-3 ${p.stock === 0 ? "font-semibold text-destructive" : ""}`}>{p.stock}</td>
                  <td className="p-3"><Switch checked={p.is_active} onCheckedChange={(v) => toggle(p.id, v)} /></td>
                  <td className="p-3"><Button asChild size="sm" variant="outline"><Link to="/admin/products/$id" params={{ id: p.id }}>Edit</Link></Button></td>
                </tr>
              );
            })}
            {!isLoading && list.length === 0 && <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">No products found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
