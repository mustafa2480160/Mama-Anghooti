import { requireLevel } from "@/lib/staff";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/admin/settings")({ beforeLoad: ({ context }) => requireLevel(context.level, 3), component: Settings });

const TEXT = [
  ["announcement", "Top banner announcement"], ["phone_primary", "Phone (main)"], ["phone_secondary", "Phone (second)"],
  ["whatsapp", "WhatsApp number"], ["email", "Email"], ["address", "Shop address"], ["opening_hours", "Opening hours"],
  ["pickup_instructions", "Pickup instructions"], ["instagram_url", "Instagram link"], ["tiktok_url", "TikTok link"], ["facebook_url", "Facebook link"],
] as const;
const NUM = [["base_fee", "Base delivery fee (Rs.)"], ["base_km", "Distance included in base fee (km)"], ["step_fee", "Extra fee per step (Rs.)"], ["step_km", "Step size (km)"], ["max_radius_km", "Max delivery distance (km, empty = no limit)"], ["payment_window_minutes", "Minutes allowed to pay"]] as const;

type S = Record<string, string | boolean> & { delivery_enabled?: boolean; pickup_enabled?: boolean; cod_enabled?: boolean; unsupported_areas?: string };

function Settings() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["admin", "settings"], queryFn: async () => (await supabase.from("store_settings").select("*").eq("id", 1).single()).data });
  const [s, setS] = useState<S>({});
  useEffect(() => {
    if (!data) return;
    const o: S = {};
    for (const [k] of TEXT) o[k] = data[k] ?? "";
    for (const [k] of NUM) o[k] = data[k] == null ? "" : String(data[k]);
    o.delivery_enabled = data.delivery_enabled; o.cod_enabled = data.cod_enabled; o.pickup_enabled = data.pickup_enabled;
    o.unsupported_areas = data.unsupported_areas.join("\n");
    setS(o);
  }, [data]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const patch: Record<string, unknown> = { cod_enabled: s.cod_enabled, delivery_enabled: s.delivery_enabled, pickup_enabled: s.pickup_enabled };
    for (const [k] of TEXT) patch[k] = String(s[k] ?? "").trim();
    for (const [k, label] of NUM) {
      const raw = String(s[k] ?? "").trim();
      if (k === "max_radius_km" && raw === "") { patch[k] = null; continue; }
      const n = Number(raw);
      if (!Number.isFinite(n) || n < 0 || (k.endsWith("_km") && n === 0)) return void toast.error(`Check "${label}".`);
      patch[k] = n;
    }
    patch["unsupported_areas"] = String(s.unsupported_areas ?? "").split("\n").map((x) => x.trim()).filter(Boolean);
    const { error } = await supabase.from("store_settings").update(patch as never).eq("id", 1);
    if (error) toast.error(error.message); else { toast.success("Settings saved"); qc.invalidateQueries(); }
  }
  if (!data) return <p>Loading…</p>;
  return (
    <form onSubmit={save} className="max-w-3xl space-y-6">
      <h1 className="font-display text-3xl font-bold">Settings</h1>
      <section className="space-y-4 rounded-2xl border bg-card p-6">
        <h2 className="font-semibold">Delivery & pickup</h2>
        <div className="flex gap-6 text-sm">
          <label className="flex items-center gap-2"><Switch checked={!!s.delivery_enabled} onCheckedChange={(v) => setS({ ...s, delivery_enabled: v })} /> Home delivery</label>
          <label className="flex items-center gap-2"><Switch checked={!!s.pickup_enabled} onCheckedChange={(v) => setS({ ...s, pickup_enabled: v })} /> Store pickup</label>
          <label className="flex items-center gap-2"><Switch checked={!!s.cod_enabled} onCheckedChange={(v) => setS({ ...s, cod_enabled: v })} /> Cash on delivery</label>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {NUM.map(([k, l]) => <div key={k}><Label>{l}</Label><Input type="number" step="any" value={String(s[k] ?? "")} onChange={(e) => setS({ ...s, [k]: e.target.value })} /></div>)}
        </div>
        <div><Label>Areas you don't deliver to (one per line)</Label><Textarea rows={3} value={String(s.unsupported_areas ?? "")} onChange={(e) => setS({ ...s, unsupported_areas: e.target.value })} /></div>
      </section>
      <section className="grid gap-4 rounded-2xl border bg-card p-6 sm:grid-cols-2">
        <h2 className="font-semibold sm:col-span-2">Shop details</h2>
        {TEXT.map(([k, l]) => <div key={k}><Label>{l}</Label><Input value={String(s[k] ?? "")} onChange={(e) => setS({ ...s, [k]: e.target.value })} /></div>)}
      </section>
      <Button type="submit">Save settings</Button>
    </form>
  );
}
