import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { canAssign, requireLevel, ROLE_LABEL } from "@/lib/staff";

export const Route = createFileRoute("/admin/staff")({
  beforeLoad: ({ context }) => requireLevel(context.level, 2),
  component: Staff,
});

const RANK = { admin: 3, manager: 2, employee: 1 } as const;

function Staff() {
  const { level } = Route.useRouteContext();
  const qc = useQueryClient();
  const options = canAssign(level);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"manager" | "employee">(options[options.length - 1] ?? "employee");
  const { data, error } = useQuery({
    queryKey: ["admin", "staff"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("list_staff");
      if (error) throw error;
      return data;
    },
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin", "staff"] });

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.rpc("set_staff_role", { _email: email.trim(), _role: role });
    if (error) return void toast.error(error.message);
    toast.success("Access given"); setEmail(""); refresh();
  }
  async function change(email: string, r: "manager" | "employee") {
    const { error } = await supabase.rpc("set_staff_role", { _email: email, _role: r });
    if (error) toast.error(error.message); else { toast.success("Updated"); refresh(); }
  }
  async function remove(id: string, email: string) {
    if (!confirm(`Remove all admin access for ${email}?`)) return;
    const { error } = await supabase.rpc("remove_staff", { _user_id: id });
    if (error) toast.error(error.message); else { toast.success("Removed"); refresh(); }
  }

  return (
    <div className="max-w-3xl space-y-6">
      <h1 className="font-display text-3xl font-bold">Staff</h1>
      <div className="rounded-2xl border bg-card p-5 text-sm space-y-1">
        <p><b>Owner</b> — everything, including shop settings and adding managers.</p>
        <p><b>Manager</b> — products, pictures, categories, orders, messages, and adding/removing employees.</p>
        <p><b>Employee</b> — view and update orders, read messages.</p>
      </div>
      <form onSubmit={add} className="space-y-2 rounded-2xl border bg-card p-5">
        <p className="text-sm text-muted-foreground">The person must first create an account on the admin login page, then enter their email here.</p>
        <div className="flex flex-wrap gap-2">
          <Input type="email" required placeholder="staff@email.com" value={email} onChange={(e) => setEmail(e.target.value)} className="max-w-xs" />
          <select aria-label="Role" value={role} onChange={(e) => setRole(e.target.value as "manager" | "employee")} className="rounded-md border bg-background px-3 text-sm">
            {options.map((o) => <option key={o} value={o}>{ROLE_LABEL[o]}</option>)}
          </select>
          <Button type="submit">Give access</Button>
        </div>
      </form>
      {error && <p className="text-sm text-destructive">{(error as Error).message}</p>}
      <ul className="divide-y rounded-2xl border bg-card">
        {data?.map((s) => {
          const editable = RANK[s.role as keyof typeof RANK] < level;
          return (
            <li key={s.user_id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
              <span className="flex-1 break-all">{s.email}</span>
              {editable && options.length > 1 ? (
                <select aria-label={`Role for ${s.email}`} value={s.role} onChange={(e) => change(s.email, e.target.value as "manager" | "employee")} className="rounded-md border bg-background px-2 py-1">
                  {options.map((o) => <option key={o} value={o}>{ROLE_LABEL[o]}</option>)}
                </select>
              ) : (
                <span className="rounded-full bg-secondary px-3 py-1 font-semibold">{ROLE_LABEL[s.role as keyof typeof ROLE_LABEL] ?? s.role}</span>
              )}
              {editable && <Button size="sm" variant="outline" onClick={() => remove(s.user_id, s.email)}>Remove</Button>}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
