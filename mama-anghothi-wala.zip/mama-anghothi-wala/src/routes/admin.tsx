import { createFileRoute, Link, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { LEVEL_LABEL } from "@/lib/staff";

export const Route = createFileRoute("/admin")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/admin/login" });
    const { data: level } = await supabase.rpc("staff_level", { _user_id: data.user.id });
    if (!level) throw redirect({ to: "/admin/login" });
    return { adminEmail: data.user.email, level: level as number };
  },
  head: () => ({
    meta: [
      { title: "Admin — Mama Anghothi Wala" },
      { name: "description", content: "Manage products, orders and settings." },
      { property: "og:title", content: "Admin — Mama Anghothi Wala" },
      { property: "og:description", content: "Manage products, orders and settings." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminLayout,
});

const NAV = [
  { to: "/admin", label: "Overview", min: 1 },
  { to: "/admin/products", label: "Products", min: 2 },
  { to: "/admin/categories", label: "Categories", min: 2 },
  { to: "/admin/orders", label: "Orders", min: 1 },
  { to: "/admin/messages", label: "Messages", min: 1 },
  { to: "/admin/staff", label: "Staff", min: 2 },
  { to: "/admin/settings", label: "Settings", min: 3 },
] as const;

function AdminLayout() {
  const { adminEmail, level } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/admin/login", replace: true });
  }
  return (
    <div className="min-h-screen bg-secondary/40">
      <header className="border-b bg-primary text-primary-foreground">
        <div className="container-shop flex flex-wrap items-center gap-4 py-3">
          <Link to="/admin" className="font-display text-lg font-bold">MAW Admin</Link>
          <nav className="flex flex-1 flex-wrap gap-1 text-sm">
            {NAV.filter((n) => level >= n.min).map((n) => (
              <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/admin" }}
                className="rounded-full px-3 py-1 hover:bg-primary-foreground/10"
                activeProps={{ className: "bg-primary-foreground/20 font-semibold" }}>{n.label}</Link>
            ))}
          </nav>
          <span className="hidden text-xs opacity-80 md:inline">{adminEmail} · {LEVEL_LABEL[level]}</span>
          <Link to="/" className="text-sm underline">View shop</Link>
          <Button size="sm" variant="secondary" onClick={signOut}>Sign out</Button>
        </div>
      </header>
      <div className="container-shop py-8"><Outlet /></div>
    </div>
  );
}
