import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/shop/Logo";

export const Route = createFileRoute("/admin_/login")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin Login — Mama Anghothi Wala" },
      { name: "description", content: "Shop owner sign-in for Mama Anghothi Wala." },
      { property: "og:title", content: "Admin Login — Mama Anghothi Wala" },
      { property: "og:description", content: "Shop owner sign-in for Mama Anghothi Wala." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [noAdmin, setNoAdmin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    supabase.rpc("admin_exists").then(({ data }) => setNoAdmin(data === false));
  }, []);

  async function enterIfAdmin() {
    await supabase.rpc("claim_first_admin");
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) return;
    const { data: ok } = await supabase.rpc("staff_level", { _user_id: u.user.id });
    if (ok) navigate({ to: "/admin", replace: true });
    else {
      await supabase.auth.signOut();
      setMsg("This account doesn't have staff access yet. Ask the owner or a manager to add you..");
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) return setMsg(error.message === "Invalid login credentials" ? "Wrong email or password." : error.message);
        await enterIfAdmin();
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/admin/login` },
        });
        if (error) return setMsg(error.message);
        if (data.session) await enterIfAdmin();
        else setMsg("Check your email and click the confirmation link, then sign in here.");
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary px-4">
      <div className="w-full max-w-sm rounded-3xl border bg-card p-8 shadow-lg">
        <Logo />
        <h1 className="mt-6 font-display text-2xl font-bold">{mode === "signin" ? "Admin sign in" : "Create owner account"}</h1>
        {noAdmin && mode === "signin" && (
          <p className="mt-2 text-sm text-muted-foreground">
            No admin yet.{" "}
            <button className="font-semibold text-primary underline" onClick={() => setMode("signup")}>Create the owner account</button>
          </p>
        )}
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div><Label htmlFor="email">Email</Label><Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <div><Label htmlFor="pw">Password</Label><Input id="pw" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          {msg && <p className="text-sm text-destructive">{msg}</p>}
          <Button type="submit" className="w-full" disabled={busy}>{busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}</Button>
        </form>
        {mode === "signup" && <button className="mt-4 text-sm underline" onClick={() => setMode("signin")}>Back to sign in</button>}
      </div>
    </div>
  );
}
