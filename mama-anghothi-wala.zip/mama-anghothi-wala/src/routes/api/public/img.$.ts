import { createFileRoute } from "@tanstack/react-router";

// Serves product images from the private storage bucket (read-only, path-restricted).
export const Route = createFileRoute("/api/public/img/$")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const path = decodeURIComponent(params._splat ?? "");
        if (!/^[a-zA-Z0-9/_\-.]{1,200}$/.test(path) || path.includes("..")) {
          return new Response("Not found", { status: 404 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data, error } = await supabaseAdmin.storage.from("product-images").download(path);
        if (error || !data) return new Response("Not found", { status: 404 });
        const type = data.type && data.type.startsWith("image/") ? data.type : "image/jpeg";
        return new Response(data, {
          headers: {
            "content-type": type,
            "cache-control": "public, max-age=86400, immutable",
            "x-content-type-options": "nosniff",
          },
        });
      },
    },
  },
});
