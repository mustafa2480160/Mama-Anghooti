import { createFileRoute } from "@tanstack/react-router";

// Safepay webhook. Signature is verified, then the payment is re-verified directly with Safepay
// before any order is marked paid, so replays or forged payloads cannot mark orders paid.
export const Route = createFileRoute("/api/public/safepay-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { safepayConfig, verifyWebhookSignature } = await import("@/server/safepay.server");
        const cfg = safepayConfig();
        if (!cfg?.webhookSecret) return new Response("Not configured", { status: 503 });
        const raw = await request.text();
        if (raw.length > 100_000) return new Response("Too large", { status: 413 });
        const ok = await verifyWebhookSignature(cfg.webhookSecret, raw, request.headers.get("x-sfpy-signature"));
        if (!ok) return new Response("Invalid signature", { status: 401 });

        let body: { type?: string; data?: { tracker?: string; token?: string; notification?: { tracker?: string } } };
        try {
          body = JSON.parse(raw);
        } catch {
          return new Response("Bad request", { status: 400 });
        }
        const tracker = body.data?.tracker ?? body.data?.notification?.tracker ?? body.data?.token;
        if (!tracker || typeof tracker !== "string" || tracker.length > 100) return new Response("ok");

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: payment } = await supabaseAdmin.from("payments").select("id").eq("tracker", tracker).maybeSingle();
        const eventKey = `webhook:${tracker}:${body.type ?? "event"}`;
        const { error: dupErr } = await supabaseAdmin.from("payment_events").insert({
          payment_id: payment?.id ?? null,
          event_key: eventKey,
          event_type: body.type ?? "unknown",
          source: "webhook",
          payload: { type: body.type ?? null, tracker },
        });
        if (dupErr && !dupErr.message.includes("duplicate")) console.error("payment event insert", dupErr.message);
        if (payment) {
          const { settlePayment } = await import("@/server/shop.server");
          await settlePayment(payment.id);
        }
        return new Response("ok");
      },
    },
  },
});
