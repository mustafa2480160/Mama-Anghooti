import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { AlertTriangle, Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { imgUrl, rs } from "@/lib/format";
import { validateCart } from "@/lib/shop.functions";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Bag — Mama Anghothi Wala" },
      { name: "description", content: "Review the items in your shopping bag." },
      { property: "og:title", content: "Your Bag — Mama Anghothi Wala" },
      { property: "og:description", content: "Review your bag and check out." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const cart = useCart();
  const validate = useServerFn(validateCart);
  const [problems, setProblems] = useState<Record<string, string>>({});
  const [checking, setChecking] = useState(false);

  // Refresh prices/stock from the server whenever the bag changes.
  const sig = cart.items.map((i) => `${i.productId}:${i.variantId}:${i.quantity}`).join("|");
  useEffect(() => {
    if (!cart.hydrated || cart.items.length === 0) return;
    let live = true;
    setChecking(true);
    validate({ data: { items: cart.items.map((i) => ({ productId: i.productId, variantId: i.variantId, quantity: i.quantity })) } })
      .then((res) => {
        if (!live) return;
        const pr: Record<string, string> = {};
        let changed = false;
        const next = cart.items.map((i) => {
          const r = res.find((x) => x.productId === i.productId && x.variantId === i.variantId);
          const key = `${i.productId}:${i.variantId}`;
          if (!r || !r.ok) {
            pr[key] = r?.problem ?? "Unavailable";
            return i;
          }
          if (r.problem) pr[key] = r.problem;
          if (r.unitPrice !== i.unitPrice || r.stock !== i.maxStock) {
            changed = true;
            return { ...i, unitPrice: r.unitPrice, maxStock: r.stock, name: r.name };
          }
          return i;
        });
        setProblems(pr);
        if (changed) cart.replace(next);
      })
      .catch(() => {})
      .finally(() => live && setChecking(false));
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig, cart.hydrated]);

  if (!cart.hydrated) return <div className="container-shop min-h-[50vh] py-16" />;

  if (cart.items.length === 0) {
    return (
      <div className="container-shop flex min-h-[55vh] flex-col items-center justify-center py-16 text-center">
        <p className="text-6xl" aria-hidden>🛍️</p>
        <h1 className="mt-4 font-display text-4xl font-extrabold">Your bag is empty</h1>
        <p className="mt-2 text-muted-foreground">Time to find something shiny.</p>
        <Button asChild variant="pop" size="lg" className="mt-6"><Link to="/shop">Start shopping</Link></Button>
      </div>
    );
  }

  const blocked = Object.keys(problems).length > 0;

  return (
    <div className="container-shop py-10 md:py-14">
      <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">Your bag <span className="font-serif font-normal italic text-primary">({cart.count})</span></h1>
      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <ul className="divide-y divide-border rounded-3xl border bg-card">
          {cart.items.map((i) => {
            const key = `${i.productId}:${i.variantId}`;
            return (
              <li key={key} className="flex gap-4 p-4 sm:p-5">
                <Link to="/product/$slug" params={{ slug: i.slug }} className="size-24 shrink-0 overflow-hidden rounded-2xl bg-muted sm:size-28">
                  <img src={imgUrl(i.image)} alt={i.name} loading="lazy" className="size-full object-cover" />
                </Link>
                <div className="flex min-w-0 flex-1 flex-col">
                  <div className="flex justify-between gap-2">
                    <div className="min-w-0">
                      <Link to="/product/$slug" params={{ slug: i.slug }} className="font-display font-bold hover:text-primary">{i.name}</Link>
                      {i.variantLabel && <p className="text-sm text-muted-foreground">{i.variantLabel}</p>}
                      <p className="text-sm text-muted-foreground">{rs(i.unitPrice)} each</p>
                    </div>
                    <button onClick={() => cart.remove(i.productId, i.variantId)} className="grid size-10 shrink-0 place-items-center rounded-full hover:bg-secondary" aria-label={`Remove ${i.name}`}>
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                  {problems[key] && (
                    <p className="mt-1 flex items-center gap-1 text-sm font-medium text-destructive"><AlertTriangle className="size-4" /> {problems[key]}</p>
                  )}
                  <div className="mt-auto flex items-center justify-between pt-3">
                    <div className="flex items-center rounded-full border">
                      <button className="grid size-10 place-items-center" aria-label="Decrease" onClick={() => cart.setQty(i.productId, i.variantId, i.quantity - 1)}><Minus className="size-4" /></button>
                      <span className="w-8 text-center text-sm font-semibold">{i.quantity}</span>
                      <button className="grid size-10 place-items-center disabled:opacity-30" aria-label="Increase" disabled={i.quantity >= i.maxStock} onClick={() => cart.setQty(i.productId, i.variantId, i.quantity + 1)}><Plus className="size-4" /></button>
                    </div>
                    <span className="font-display font-extrabold">{rs(i.unitPrice * i.quantity)}</span>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
        <aside className="h-fit rounded-3xl border-2 border-maroon-deep bg-card p-6 shadow-pop lg:sticky lg:top-28">
          <h2 className="font-display text-xl font-extrabold">Summary</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd className="font-semibold">{rs(cart.subtotal)}</dd></div>
            <div className="flex justify-between text-muted-foreground"><dt>Delivery</dt><dd>Calculated at checkout</dd></div>
          </dl>
          <p className="mt-3 text-xs text-muted-foreground">Pickup is free. Delivery is Rs. 130 for the first 10 km by road.</p>
          <Button asChild={!blocked} size="lg" variant="pop" className="mt-6 w-full" disabled={blocked || checking}>
            {blocked ? <span>Fix bag issues to continue</span> : <Link to="/checkout">Checkout</Link>}
          </Button>
          <Link to="/shop" className="mt-3 block text-center text-sm text-primary hover:underline">Keep shopping</Link>
        </aside>
      </div>
    </div>
  );
}
