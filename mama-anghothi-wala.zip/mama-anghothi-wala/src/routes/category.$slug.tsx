import { createFileRoute, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Listing, listSearchSchema } from "@/components/shop/Listing";
import { storeInfoQuery } from "@/lib/queries";

export const Route = createFileRoute("/category/$slug")({
  validateSearch: listSearchSchema,
  loader: async ({ context, params }) => {
    const info = await context.queryClient.ensureQueryData(storeInfoQuery);
    const cat = info.categories.find((c) => c.slug === params.slug);
    if (!cat) throw notFound();
    return { name: cat.name, description: cat.description };
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.name} — Mama Anghothi Wala` : "Category — Mama Anghothi Wala";
    const d = loaderData?.description ?? "Shop artificial jewellery by category.";
    return {
      meta: [
        { title: t },
        { name: "description", content: d },
        { property: "og:title", content: t },
        { property: "og:description", content: d },
      ],
    };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { data } = useSuspenseQuery(storeInfoQuery);
  const cat = data.categories.find((c) => c.slug === slug);
  return (
    <Listing
      key={slug}
      title={cat?.name ?? "Category"}
      kicker="shop"
      description={cat?.description}
      category={slug}
      search={Route.useSearch()}
    />
  );
}
