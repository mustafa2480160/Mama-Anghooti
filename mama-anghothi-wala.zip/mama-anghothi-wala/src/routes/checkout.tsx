import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { Banknote, CreditCard, Loader2, Lock, MapPin, Store, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { imgUrl, rs } from "@/lib/format";
import { storeInfoQuery } from "@/lib/queries";
import { getDeliveryQuote, placeOrder } from "@/lib/shop.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — Mama Anghothi Wala" },
      { name: "description", content: "Choose delivery or pickup and pay securely online." },
      { property: "og:title", content: "Checkout — Mama Anghothi Wala" },
      { property: "og:description", content: "Secure checkout." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Checkout,
});

const phoneRe = /^(\+92|0092|0)?3\d{9}$/;
const IDEM_KEY = "maw-checkout-key";

function Checkout() {
  const cart = useCart();
  const navigate = useNavigate();
  const { data: info } = useQuery(storeInfoQuery);
  const quoteFn = useServerFn(getDeliveryQuote);
  const placeFn = useServerFn(placeOrder);
  const [method, setMethod] = useState<"delivery" | "pickup">("delivery");
  const [payMethod, setPayMethod] = useState<"online" | "cod">("online");
  const [f, setF] = useState({ name: "", phone: "", email: "", address: "", area: "", city: "Karachi", landmark: "", notes: "", website: "" });
  const [errors, setErrors] = useState<Partial<Record<"name"|"phone"|"email"|"address"|"area"|"city"|"quote", string>>>({});
  const [quote, setQuote] = useState<{ fee: number; distanceKm: number; for: string } | null>(null);
  const [quoteErr, setQuoteErr] = useState<string | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formErr, setFormErr] = useState<string | null>(null);
  const submitLock = useRef(false);

  const addrKey = `${f.address}|${f.area}|${f.city}`;
  const quoteValid = quote && quote.for === addrKey;

  useEffect(() => {
    if (info && !info.settings.delivery_enabled) setMethod("pickup");
  }, [info]);

  if (!cart.hydrated) return <div className="min-h-[50vh]" />;
  if (cart.items.length === 0) {
    return (
      <div className="container-shop py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Your bag is empty</h1>
        <Button asChild variant="pop" className="mt-6"><Link to="/shop">Shop now</Link></Button>
      </div>
    );
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setF((p) => ({ ...p, [k]: e.target.value }));
    setErrors((p) => ({ ...p, [k]: "" }));
  };

  const calcQuote = async () => {
    const errs: Partial<Record<"address"|"area"|"city", string>> = {};
    if (f.address.trim().length < 8) errs.address = "Please enter your full address (house, street, block)";
    if (f.area.trim().length < 2) errs.area = "Please enter your area";
    if (f.city.trim().length < 2) errs.city = "Please enter your city";
    setErrors((p) => ({ ...p, ...errs }));
    if (Object.keys(errs).length) return;
    setQuoting(true);
    setQuoteErr(null);
    try {
      const r = await quoteFn({ data: { address: f.address, area: f.area, city: f.city } });
      if (r.ok) setQuote({ ...r.data, for: addrKey });
      else { setQuote(null); setQuoteErr(r.error); }
    } catch {
      setQuoteErr("Couldn't calculate delivery. Please try again.");
    } finally {
      setQuoting(false);
    }
  };

  const validate = () => {
    const e: Partial<Record<"name"|"phone"|"email"|"address"|"area"|"city"|"quote", string>> = {};
    if (f.name.trim().length < 2) e.name = "Please enter your full name";
    if (!phoneRe.test(f.phone.replace(/[\s-]/g, ""))) e.phone = "Enter a valid mobile number, e.g. 03001234567";
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) e.email = "Enter a valid email or leave it empty";
    if (method === "delivery") {
      if (f.address.trim().length < 8) e.address = "Please enter your full address";
      if (f.area.trim().length < 2) e.area = "Please enter your area";
      if (!quoteValid) e.quote = "Please calculate the delivery charge first";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    if (submitLock.current) return;
    setFormErr(null);
    if (!validate()) return;
    submitLock.current = true;
    setSubmitting(true);
    let key = sessionStorage.getItem(IDEM_KEY);
    if (!key) { key = crypto.randomUUID(); sessionStorage.setItem(IDEM_KEY, key); }
    try {
      const r = await placeFn({
        data: {
          idempotencyKey: key,
          fulfilment: method,
          paymentMethod: method === "delivery" ? payMethod : "online",
          items: cart.items.map((i) => ({ productId: i.productId, variantId: i.variantId, quantity: i.quantity })),
          customer: {
            name: f.name, phone: f.phone, email: f.email,
            address: method === "delivery" ? f.address : undefined,
            area: method === "delivery" ? f.area : undefined,
            city: method === "delivery" ? f.city : undefined,
            landmark: method === "delivery" ? f.landmark : undefined,
            notes: f.notes,
          },
          website: f.website,
        },
      });
      if (!r.ok) {
        setFormErr(r.error);
        // order wasn't created; a fresh attempt may use a new key
        sessionStorage.removeItem(IDEM_KEY);
        return;
      }
      sessionStorage.removeItem(IDEM_KEY);
      cart.clear();
      if ("cod" in r.data && r.data.cod) {
        navigate({ to: "/order/$token", params: { token: r.data.token } });
        return;
      }
      if (r.data.paymentUrl) {
        window.location.href = r.data.paymentUrl;
        return;
      }
      navigate({ to: "/payment", search: { order: r.data.token } });
    } catch {
      setFormErr("We couldn't reach the server. Please check your connection and try again — you won't be charged twice.");
    } finally {
      submitLock.current = false;
      setSubmitting(false);
    }
  };

  const fee = method === "pickup" ? 0 : quoteValid ? quote!.fee : null;
  const total = cart.subtotal + (fee ?? 0);
  const isCod = method === "delivery" && payMethod === "cod" && info?.settings.cod_enabled !== false;
  const input = "mt-1 h-12 w-full rounded-2xl border border-input bg-card px-4 outline-none focus:border-primary aria-[invalid=true]:border-destructive";
  const Err = ({ k }: { k: keyof typeof errors }) => (errors[k] ? <p className="mt-1 text-sm text-destructive" role="alert">{errors[k]}</p> : null);
  const s = info?.settings;

  return (
    <div className="container-shop py-10 md:py-14">
      <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">Checkout</h1>
      <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground"><Lock className="size-4" /> Guest checkout · Cash on delivery for home delivery · Pickup orders paid online</p>

      <form onSubmit={submit} noValidate className="mt-8 grid gap-8 lg:grid-cols-[1fr_400px]">
        <div className="space-y-8">
          <section className="rounded-3xl border bg-card p-5 sm:p-7">
            <h2 className="font-display text-xl font-extrabold">1. How do you want it?</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label="Fulfilment method">
              {([
                ["delivery", Truck, "Home delivery", `From ${rs(s?.base_fee ?? 130)} · by road distance`, s?.delivery_enabled !== false],
                ["pickup", Store, "Store pickup", "Free · Bolton Market, Karachi", s?.pickup_enabled !== false],
              ] as const).map(([val, Icon, title, sub, enabled]) => (
                <button
                  type="button"
                  role="radio"
                  aria-checked={method === val}
                  disabled={!enabled}
                  key={val}
                  onClick={() => setMethod(val)}
                  className={cn(
                    "flex items-start gap-3 rounded-2xl border-2 p-4 text-left transition-all disabled:opacity-40",
                    method === val ? "border-primary bg-secondary shadow-pop" : "border-border hover:border-primary/50",
                  )}
                >
                  <Icon className="mt-0.5 size-5 text-primary" />
                  <span><span className="block font-semibold">{title}</span><span className="text-sm text-muted-foreground">{enabled ? sub : "Currently unavailable"}</span></span>
                </button>
              ))}
            </div>
            {method === "pickup" && s && (
              <div className="mt-4 rounded-2xl bg-blush/60 p-4 text-sm">
                <p className="flex gap-2 font-semibold"><MapPin className="size-4 shrink-0" /> {s.address}, {s.city}</p>
                <p className="mt-1 text-muted-foreground">Open {s.opening_hours}. Collect after we mark your order "Ready for Pickup". Payment must be completed online first.</p>
              </div>
            )}
          </section>

          <section className="rounded-3xl border bg-card p-5 sm:p-7">
            <h2 className="font-display text-xl font-extrabold">2. Your details</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2"><span className="text-sm font-medium">Full name *</span>
                <input className={input} autoComplete="name" value={f.name} onChange={set("name")} aria-invalid={!!errors.name} /><Err k="name" /></label>
              <label><span className="text-sm font-medium">Mobile number *</span>
                <input className={input} type="tel" inputMode="tel" autoComplete="tel" placeholder="03001234567" value={f.phone} onChange={set("phone")} aria-invalid={!!errors.phone} /><Err k="phone" /></label>
              <label><span className="text-sm font-medium">Email (optional)</span>
                <input className={input} type="email" autoComplete="email" value={f.email} onChange={set("email")} aria-invalid={!!errors.email} /><Err k="email" /></label>
            </div>
            <input tabIndex={-1} autoComplete="off" aria-hidden className="hidden" value={f.website} onChange={set("website")} name="website" />
          </section>

          {method === "delivery" && (
            <section className="rounded-3xl border bg-card p-5 sm:p-7">
              <h2 className="font-display text-xl font-extrabold">3. Delivery address</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <label className="sm:col-span-2"><span className="text-sm font-medium">Complete address *</span>
                  <input className={input} autoComplete="street-address" placeholder="House #, street, block" value={f.address} onChange={set("address")} aria-invalid={!!errors.address} /><Err k="address" /></label>
                <label><span className="text-sm font-medium">Area *</span>
                  <input className={input} placeholder="e.g. Gulshan-e-Iqbal" value={f.area} onChange={set("area")} aria-invalid={!!errors.area} /><Err k="area" /></label>
                <label><span className="text-sm font-medium">City *</span>
                  <input className={input} autoComplete="address-level2" value={f.city} onChange={set("city")} aria-invalid={!!errors.city} /><Err k="city" /></label>
                <label className="sm:col-span-2"><span className="text-sm font-medium">Nearby landmark</span>
                  <input className={input} value={f.landmark} onChange={set("landmark")} /></label>
              </div>
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <Button type="button" variant="outline" onClick={calcQuote} disabled={quoting}>
                  {quoting ? <Loader2 className="animate-spin" /> : <Truck />} {quoteValid ? "Recalculate" : "Calculate delivery charge"}
                </Button>
                {quoteValid && <p className="text-sm font-semibold text-success">{quote!.distanceKm} km by road → {rs(quote!.fee)}</p>}
              </div>
              {quoteErr && <p className="mt-2 text-sm text-destructive" role="alert">{quoteErr}</p>}
              <Err k="quote" />
            </section>
          )}

          <section className="rounded-3xl border bg-card p-5 sm:p-7">
            <h2 className="font-display text-xl font-extrabold">{method === "delivery" ? "4." : "3."} Payment</h2>
            {method === "delivery" ? (
              <div className="mt-4 grid gap-3 sm:grid-cols-2" role="radiogroup" aria-label="Payment method">
                {([
                  ["cod", Banknote, "Cash on delivery", "Pay the rider when it arrives", s?.cod_enabled !== false],
                  ["online", CreditCard, "Pay online now", "Card or wallet via Safepay", true],
                ] as const).map(([val, Icon, title, sub, enabled]) => (
                  <button type="button" role="radio" aria-checked={payMethod === val} disabled={!enabled} key={val} onClick={() => setPayMethod(val)}
                    className={cn("flex items-start gap-3 rounded-2xl border-2 p-4 text-left transition-all disabled:opacity-40",
                      payMethod === val ? "border-primary bg-secondary shadow-pop" : "border-border hover:border-primary/50")}>
                    <Icon className="mt-0.5 size-5 text-primary" />
                    <span><span className="block font-semibold">{title}</span><span className="text-sm text-muted-foreground">{enabled ? sub : "Currently unavailable"}</span></span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm text-muted-foreground">Store pickup orders must be paid online in full before collection.</p>
            )}
          </section>

          <section className="rounded-3xl border bg-card p-5 sm:p-7">
            <label><span className="font-display text-lg font-extrabold">Order notes (optional)</span>
              <textarea className="mt-2 min-h-24 w-full rounded-2xl border border-input bg-card p-4 outline-none focus:border-primary" maxLength={500} value={f.notes} onChange={set("notes")} /></label>
          </section>
        </div>

        <aside className="h-fit rounded-3xl border-2 border-maroon-deep bg-card p-6 shadow-pop lg:sticky lg:top-28">
          <h2 className="font-display text-xl font-extrabold">Order summary</h2>
          <ul className="mt-4 space-y-3">
            {cart.items.map((i) => (
              <li key={`${i.productId}:${i.variantId}`} className="flex gap-3 text-sm">
                <img src={imgUrl(i.image)} alt="" className="size-14 rounded-xl object-cover" />
                <div className="flex-1"><p className="font-semibold">{i.name}</p><p className="text-muted-foreground">{i.variantLabel ? `${i.variantLabel} · ` : ""}{i.quantity} × {rs(i.unitPrice)}</p></div>
                <span className="font-semibold">{rs(i.quantity * i.unitPrice)}</span>
              </li>
            ))}
          </ul>
          <dl className="mt-5 space-y-2 border-t pt-4 text-sm">
            <div className="flex justify-between"><dt>Items subtotal</dt><dd>{rs(cart.subtotal)}</dd></div>
            <div className="flex justify-between"><dt>{method === "pickup" ? "Store pickup" : "Delivery charge"}</dt><dd>{fee == null ? "Calculate above" : fee === 0 ? "Free" : rs(fee)}</dd></div>
            <div className="flex justify-between border-t pt-3 font-display text-xl font-extrabold"><dt>{isCod ? "Pay on delivery" : "Total to pay"}</dt><dd className="text-primary">{fee == null ? "—" : rs(total)}</dd></div>
          </dl>
          <p className="mt-3 text-xs text-muted-foreground">Final amount is verified by our server before payment. Prices and stock are re-checked.</p>
          {formErr && <p className="mt-3 rounded-xl bg-destructive/10 p-3 text-sm text-destructive" role="alert">{formErr}</p>}
          <Button type="submit" size="lg" variant="gold" className="mt-5 w-full" disabled={submitting || (method === "delivery" && !quoteValid)}>
            {submitting ? <><Loader2 className="animate-spin" /> Placing order…</> : <><Lock /> {isCod ? "Place order (cash on delivery)" : "Place order & pay"} {fee != null ? rs(total) : ""}</>}
          </Button>
          <p className="mt-3 text-center text-xs text-muted-foreground">
            By placing an order you agree to our <Link to="/terms" className="underline">terms</Link> and <Link to="/returns-policy" className="underline">returns policy</Link>.
          </p>
        </aside>
      </form>
    </div>
  );
}
