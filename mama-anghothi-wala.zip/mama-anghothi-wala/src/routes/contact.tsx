import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";
import { Button } from "@/components/ui/button";
import { sendContactMessage } from "@/lib/shop.functions";

export const Route = createFileRoute("/contact")({
  head: infoHead("Contact Us", "Contact Mama Anghothi Wala — phone, WhatsApp and store address in Karachi."),
  component: Contact,
});

function Contact() {
  const send = useServerFn(sendContactMessage);
  const [f, setF] = useState({ name: "", phone: "", email: "", message: "", website: "" });
  const [state, setState] = useState<"idle" | "busy" | "ok" | "err">("idle");
  const input = "mt-1 h-12 w-full rounded-2xl border border-input bg-card px-4 outline-none focus:border-primary";
  return (
    <InfoPage kicker="say hi" title="Contact us">
      <p>Bolton Market, in front of 5 Star Biryani, near Old Memon Masjid, Karachi.</p>
      <p>Phone / WhatsApp: <a href="tel:03008908467">0300-8908467</a> · <a href="tel:03053484389">0305-3484389</a></p>
      <p>Open 10:00 am – 9:00 pm.</p>
      {state === "ok" ? (
        <p className="not-prose mt-6 rounded-2xl bg-secondary p-4">Thanks! Your message was received.</p>
      ) : (
        <form
          className="not-prose mt-6 space-y-3"
          onSubmit={async (e) => {
            e.preventDefault();
            setState("busy");
            try {
              const r = await send({ data: f });
              setState(r.ok ? "ok" : "err");
            } catch {
              setState("err");
            }
          }}
        >
          <input required minLength={2} placeholder="Name" className={input} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <input placeholder="Phone (optional)" className={input} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
          <textarea required minLength={5} placeholder="Message" className="min-h-28 w-full rounded-2xl border border-input bg-card p-4" value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} />
          {state === "err" && <p className="text-sm text-destructive">Couldn't send. Please check the fields and try again.</p>}
          <Button type="submit" variant="pop" disabled={state === "busy"}>Send message</Button>
        </form>
      )}
    </InfoPage>
  );
}
