import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";

const faqs: [string, string][] = [
  ["Do you offer cash on delivery?", "Yes, for home delivery — pay the rider in cash when your order arrives. Store pickup orders must be paid online before collection."],
  ["How much is delivery?", "Rs. 130 for the first 10 km by road, then Rs. 50 for every extra 10 km. You'll see the exact charge at checkout before paying."],
  ["Can I pick up my order?", "Yes, pickup from our Bolton Market store is free. Pay online, then collect once your order is marked Ready for Pickup."],
  ["Is the jewellery real gold?", "No — all our pieces are artificial / fashion jewellery."],
  ["How do I track my order?", "Use the Track Order page with your order number and the mobile number used at checkout."],
];

export const Route = createFileRoute("/faq")({
  head: infoHead("FAQ", "Answers about payment, delivery, pickup and orders at Mama Anghothi Wala."),
  component: () => (
    <InfoPage kicker="got questions?" title="FAQ">
      {faqs.map(([q, a]) => (
        <section key={q}><h2>{q}</h2><p>{a}</p></section>
      ))}
    </InfoPage>
  ),
});
