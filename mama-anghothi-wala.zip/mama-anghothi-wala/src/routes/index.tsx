import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight, Lock, MapPin, Sparkles, Store, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductGrid } from "@/components/shop/ProductCard";
import { homeQuery, storeInfoQuery } from "@/lib/queries";
import { imgUrl, rs } from "@/lib/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mama Anghothi Wala — Artificial Jewellery in Karachi" },
      { name: "description", content: "Shop trendy rings, chains, bracelets, necklaces & bands. Delivery across Karachi or free pickup at Bolton Market." },
      { property: "og:title", content: "Mama Anghothi Wala — Artificial Jewellery in Karachi" },
      { property: "og:description", content: "Trendy fashion jewellery. Delivery across Karachi or free store pickup." },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([context.queryClient.ensureQueryData(homeQuery), context.queryClient.ensureQueryData(storeInfoQuery)]),
  component: Home,
});

function SectionHead({ kicker, title, to, params }: { kicker: string; title: React.ReactNode; to?: "/shop"; params?: never }) {
  return (
    <div className="mb-8 flex items-end justify-between gap-4">
      <div>
        <p className="font-serif text-lg italic text-primary">{kicker}</p>
        <h2 className="font-display text-3xl font-extrabold tracking-tight sm:text-5xl">{title}</h2>
      </div>
      {to && (
        <Link to={to} className="hidden shrink-0 items-center gap-1 text-sm font-semibold text-primary hover:underline sm:inline-flex">
          See all <ArrowRight className="size-4" />
        </Link>
      )}
    </div>
  );
}

function Home() {
  const { data: home } = useSuspenseQuery(homeQuery);
  const { data: info } = useSuspenseQuery(storeInfoQuery);
  const s = info.settings;
  const cats = info.categories;
  const heroImgs = ["/images/cat-rings.jpg", "/images/cat-necklaces.jpg", "/images/cat-bracelets.jpg"];

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-hero text-ivory">
        <div className="container-shop grid items-center gap-10 py-14 md:grid-cols-2 md:py-20 lg:py-24">
          <div className="relative z-10">
            <span className="sticker -rotate-2 bg-gold text-gold-foreground"><Sparkles className="size-3" /> Karachi's fave anghothi spot</span>
            <h1 className="mt-5 font-display text-5xl font-extrabold leading-[0.92] tracking-tight sm:text-7xl lg:text-8xl">
              bling that <span className="font-serif font-normal italic text-gold-shine">hits</span> different.
            </h1>
            <p className="mt-6 max-w-md text-lg text-ivory/80">
              Rings, chains, bracelets & sets that look expensive — without the price tag. Stack 'em, gift 'em, flex 'em.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="lg"><Link to="/shop">Shop the drop <ArrowRight /></Link></Button>
              <Button asChild size="lg" className="border-2 border-ivory/40 bg-transparent text-ivory hover:bg-ivory hover:text-primary">
                <Link to="/category/$slug" params={{ slug: "rings" }}>Rings ✦</Link>
              </Button>
            </div>
            <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ivory/75">
              <span className="flex items-center gap-1.5"><Truck className="size-4 text-gold" /> Delivery from {rs(s.base_fee)}</span>
              <span className="flex items-center gap-1.5"><Store className="size-4 text-gold" /> Free pickup</span>
              <span className="flex items-center gap-1.5"><Lock className="size-4 text-gold" /> Secure online pay</span>
            </div>
          </div>
          <div className="relative mx-auto grid w-full max-w-md grid-cols-2 gap-3 md:max-w-none">
            <img src={heroImgs[0]} alt="Statement rings with maroon stones" width={600} height={600} className="col-span-2 aspect-[4/3] w-full rounded-[2rem] object-cover shadow-pop" fetchPriority="high" />
            <img src={heroImgs[1]} alt="Kundan pearl necklace" width={400} height={400} loading="lazy" className="aspect-square w-full -rotate-3 rounded-[1.5rem] object-cover" />
            <img src={heroImgs[2]} alt="Stacked gold bangles" width={400} height={400} loading="lazy" className="aspect-square w-full rotate-3 rounded-[1.5rem] object-cover" />
            <span className="sticker absolute -left-2 top-6 animate-float bg-blush text-primary [--r:-8deg]">new drops weekly</span>
            <span className="sticker absolute -right-2 bottom-10 animate-float bg-ivory text-primary [--r:6deg]">gift-ready ✦</span>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="overflow-hidden border-y-2 border-maroon-deep bg-gold py-3 text-gold-foreground" aria-hidden>
        <div className="flex w-max animate-marquee gap-10 whitespace-nowrap font-display text-xl font-extrabold uppercase">
          {Array.from({ length: 2 }).flatMap((_, k) =>
            ["rings", "chains", "bracelets", "necklaces", "bands", "jhumkas", "stack it", "gift it"].map((w, i) => (
              <span key={`${k}-${i}`} className="flex items-center gap-10">{w}<span>✦</span></span>
            )),
          )}
        </div>
      </div>

      {/* CATEGORIES */}
      <section className="container-shop py-16 md:py-20">
        <SectionHead kicker="pick your vibe" title="Shop by category" />
        <div className="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3">
          {cats.map((c, i) => (
            <Link
              key={c.slug}
              to="/category/$slug"
              params={{ slug: c.slug }}
              className="group relative aspect-[4/5] overflow-hidden rounded-3xl bg-muted sm:aspect-[4/3]"
            >
              <img src={imgUrl(c.image_url)} alt="" loading="lazy" width={600} height={600} className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-maroon-deep/85 via-maroon-deep/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-4 sm:p-6">
                <div>
                  <span className="font-serif text-sm italic text-gold">0{i + 1}</span>
                  <h3 className="font-display text-2xl font-extrabold text-ivory sm:text-3xl">{c.name}</h3>
                </div>
                <span className="grid size-10 place-items-center rounded-full bg-ivory text-primary transition-transform group-hover:-rotate-45">
                  <ArrowRight className="size-4" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {home.featured.length > 0 && (
        <section className="container-shop py-8">
          <SectionHead kicker="main character energy" title={<>Featured <span className="font-serif font-normal italic text-primary">picks</span></>} to="/shop" />
          <ProductGrid items={home.featured} />
        </section>
      )}

      {home.banners.length > 0 && (
        <section className="container-shop grid gap-4 py-12 md:grid-cols-2">
          {home.banners.map((b) => (
            <a key={b.id} href={b.link_url ?? "/shop"} className="group relative flex min-h-48 items-end overflow-hidden rounded-3xl bg-primary p-6 text-primary-foreground">
              {b.image_url && <img src={imgUrl(b.image_url)} alt="" loading="lazy" className="absolute inset-0 size-full object-cover opacity-50 transition-transform group-hover:scale-105" />}
              <div className="relative">
                <h3 className="font-display text-3xl font-extrabold">{b.title}</h3>
                {b.subtitle && <p className="mt-1 text-primary-foreground/85">{b.subtitle}</p>}
              </div>
            </a>
          ))}
        </section>
      )}

      {home.newArrivals.length > 0 && (
        <section className="container-shop py-12">
          <SectionHead kicker="fresh outta the box" title="New arrivals" to="/shop" />
          <ProductGrid items={home.newArrivals} />
        </section>
      )}

      {home.bestSellers.length > 0 && (
        <section className="container-shop py-12">
          <SectionHead kicker="everyone's adding these" title="Best sellers" to="/shop" />
          <ProductGrid items={home.bestSellers} />
        </section>
      )}

      {/* WHY + FULFILMENT */}
      <section className="container-shop py-16">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-3xl bg-blush p-7">
            <Sparkles className="size-7 text-primary" />
            <h3 className="mt-4 font-display text-2xl font-extrabold">Looks luxe, costs less</h3>
            <p className="mt-2 text-muted-foreground">Fashion jewellery picked for the trends you actually wear — clearly described, honestly photographed.</p>
          </div>
          <div className="rounded-3xl bg-primary p-7 text-primary-foreground">
            <Truck className="size-7 text-gold" />
            <h3 className="mt-4 font-display text-2xl font-extrabold">Delivery across Karachi</h3>
            <p className="mt-2 text-primary-foreground/80">
              {rs(s.base_fee)} for the first {Number(s.base_km)} km, then +{rs(s.step_fee)} per extra {Number(s.step_km)} km. Calculated by road distance before you pay.
            </p>
          </div>
          <div className="rounded-3xl border-2 border-maroon-deep bg-card p-7 shadow-pop">
            <MapPin className="size-7 text-primary" />
            <h3 className="mt-4 font-display text-2xl font-extrabold">Free store pickup</h3>
            <p className="mt-2 text-muted-foreground">{s.address}, {s.city}. Open {s.opening_hours}. Pay online, collect when it's ready.</p>
          </div>
        </div>
        <p className="mt-6 flex items-center justify-center gap-2 text-center text-sm text-muted-foreground">
          <Lock className="size-4" /> Cash on delivery for home delivery · pickup orders paid securely online.
        </p>
      </section>
    </>
  );
}
