import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { OrderDetails, type OrderView } from "@/components/shop/OrderDetails";
import { getOrder } from "@/lib/shop.functions";

export const Route = createFileRoute("/order/$token")({
  head: () => ({
    meta: [
      { title: "Your Order — Mama Anghothi Wala" },
      { name: "description", content: "Order status and details." },
      { property: "og:title", content: "Your Order — Mama Anghothi Wala" },
      { property: "og:description", content: "Order status." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrderPage,
});

function OrderPage() {
  const { token } = Route.useParams();
  const fetchOrder = useServerFn(getOrder);
  const valid = /^[a-f0-9]{48}$/.test(token);
  const q = useQuery({ queryKey: ["order", token], enabled: valid, queryFn: () => fetchOrder({ data: { token } }) });

  if (!valid || q.data === null) {
    return (
      <div className="container-shop py-20 text-center">
        <h1 className="font-display text-3xl font-extrabold">Order not found</h1>
        <Button asChild variant="pop" className="mt-6"><Link to="/track-order">Look up by order number</Link></Button>
      </div>
    );
  }
  if (q.isLoading || !q.data) return <div className="grid min-h-[50vh] place-items-center"><Loader2 className="size-8 animate-spin text-primary" /></div>;
  const o = q.data as OrderView;
  return (
    <div className="container-shop py-10 md:py-14">
      <p className="font-serif text-lg italic text-primary">order</p>
      <h1 className="mb-8 font-display text-4xl font-extrabold tracking-tight sm:text-5xl">{o.order_number}</h1>
      {o.payment_status !== "paid" && o.status !== "expired" && (
        <div className="mb-6 rounded-2xl bg-gold/30 p-4 text-sm">
          This order is not paid yet. <Link to="/payment" search={{ order: token }} className="font-semibold text-primary underline">Complete payment</Link>
        </div>
      )}
      <OrderDetails o={o} />
    </div>
  );
}
