import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { z } from "zod";
import { AlertTriangle, CheckCircle2, Clock, CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { OrderDetails, type OrderView } from "@/components/shop/OrderDetails";
import { retryPayment, verifyOrderPayment } from "@/lib/shop.functions";
import { rs } from "@/lib/format";

export const Route = createFileRoute("/payment")({
  validateSearch: z.object({
    order: z.string().regex(/^[a-f0-9]{48}$/).catch(""),
    cancelled: z.coerce.number().optional().catch(undefined),
  }),
  head: () => ({
    meta: [
      { title: "Payment — Mama Anghothi Wala" },
      { name: "description", content: "Payment status for your order." },
      { property: "og:title", content: "Payment — Mama Anghothi Wala" },
      { property: "og:description", content: "Payment status." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PaymentPage,
});

function PaymentPage() {
  const { order, cancelled } = Route.useSearch();
  const verify = useServerFn(verifyOrderPayment);
  const retry = useServerFn(retryPayment);
  const [retrying, setRetrying] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [polls, setPolls] = useState(0);

  const q = useQuery({
    queryKey: ["payment", order],
    enabled: !!order,
    queryFn: async () => {
      setPolls((n) => n + 1);
      return verify({ data: { token: order, cancelled: !!cancelled } });
    },
    refetchInterval: (query) => {
      const d = query.state.data as OrderView | null | undefined;
      if (!d || d.payment_status === "paid" || d.payment_status === "pending" || d.status === "expired") return false;
      return polls < 10 ? 4000 : false;
    },
  });

  if (!order) return <Empty text="Missing order reference." />;
  if (q.isLoading) {
    return (
      <div className="container-shop flex min-h-[50vh] flex-col items-center justify-center gap-3 py-16">
        <Loader2 className="size-8 animate-spin text-primary" />
        <p>Checking your payment with the gateway…</p>
      </div>
    );
  }
  const o = q.data as OrderView | null | undefined;
  if (!o) return <Empty text="We couldn't find that order." />;

  const paid = o.payment_status === "paid";
  const expired = o.status === "expired" || o.status === "cancelled" || new Date(o.reservation_expires_at) < new Date();

  const doRetry = async () => {
    setRetrying(true);
    setMsg(null);
    try {
      const r = await retry({ data: { token: order } });
      if (!r.ok) setMsg(r.error);
      else if (r.data.paymentUrl) window.location.href = r.data.paymentUrl;
      else if (r.data.paymentUnavailable) setMsg("Online payment isn't activated on this store yet, so this order can't be paid right now.");
      else q.refetch();
    } catch {
      setMsg("Couldn't start payment. Please try again.");
    } finally {
      setRetrying(false);
    }
  };

  return (
    <div className="container-shop py-10 md:py-14">
      <div className="mb-8 rounded-[2rem] p-6 sm:p-8 text-center bg-hero text-ivory">
        {paid ? (
          <>
            <CheckCircle2 className="mx-auto size-12 text-gold" />
            <h1 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">Payment verified! ✨</h1>
            <p className="mt-2 text-ivory/80">Order {o.order_number} is confirmed. Save this page link to track it.</p>
            <Button asChild variant="gold" className="mt-5"><Link to="/order/$token" params={{ token: order }}>View order</Link></Button>
          </>
        ) : expired ? (
          <>
            <Clock className="mx-auto size-12 text-gold" />
            <h1 className="mt-3 font-display text-4xl font-extrabold">Payment window expired</h1>
            <p className="mt-2 text-ivory/80">This order wasn't paid in time, so the items were released. Please place a new order.</p>
            <Button asChild variant="gold" className="mt-5"><Link to="/shop">Back to shop</Link></Button>
          </>
        ) : (
          <>
            {o.payment_status === "failed" || o.payment_status === "cancelled" ? (
              <AlertTriangle className="mx-auto size-12 text-gold" />
            ) : (
              <CreditCard className="mx-auto size-12 text-gold" />
            )}
            <h1 className="mt-3 font-display text-3xl font-extrabold sm:text-4xl">
              {o.payment_status === "failed" ? "Payment failed" : o.payment_status === "cancelled" ? "Payment cancelled" : o.payment_status === "processing" ? "Waiting for payment confirmation" : "Payment needed"}
            </h1>
            <p className="mx-auto mt-2 max-w-lg text-ivory/80">
              Your order is reserved until {new Date(o.reservation_expires_at).toLocaleTimeString("en-PK", { hour: "numeric", minute: "2-digit" })}. It is only confirmed once {rs(o.total)} is paid online and verified.
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-3">
              <Button variant="gold" onClick={doRetry} disabled={retrying}>
                {retrying ? <Loader2 className="animate-spin" /> : <CreditCard />} Pay {rs(o.total)} securely
              </Button>
              {o.payment_status === "processing" && (
                <Button className="border-2 border-ivory/40 bg-transparent text-ivory hover:bg-ivory hover:text-primary" onClick={() => q.refetch()}>I've paid — check again</Button>
              )}
            </div>
            {msg && <p className="mx-auto mt-4 max-w-md rounded-xl bg-ivory/10 p-3 text-sm" role="alert">{msg}</p>}
          </>
        )}
      </div>
      <OrderDetails o={o} />
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return (
    <div className="container-shop py-20 text-center">
      <h1 className="font-display text-3xl font-extrabold">{text}</h1>
      <Button asChild variant="pop" className="mt-6"><Link to="/track-order">Look up an order</Link></Button>
    </div>
  );
}
