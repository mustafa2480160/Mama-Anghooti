import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";
import { storeInfoQuery } from "@/lib/queries";

export const Route = createFileRoute("/pickup-policy")({
  head: infoHead("Store Pickup", "Collect your order for free from our store at Bolton Market, Karachi."),
  loader: ({ context }) => context.queryClient.ensureQueryData(storeInfoQuery),
  component: Page,
});

function Page() {
  const { data } = useSuspenseQuery(storeInfoQuery);
  const s = data.settings;
  return (
    <InfoPage kicker="collect in store" title="Store pickup">
      <p>Pickup is <strong>free</strong> — no delivery charge.</p>
      <h2>Where</h2>
      <p>{s.address}, {s.city}</p>
      <h2>When</h2>
      <p>{s.opening_hours}</p>
      <h2>How it works</h2>
      <ul>
        <li>Pay the full order amount online at checkout. Pickup orders are not confirmed until payment is verified, and we don't accept cash at the counter.</li>
        <li>We'll prepare your items and mark your order "Ready for Pickup". You can check the status any time on the <a href="/track-order">order tracking page</a>.</li>
        <li>{s.pickup_instructions}</li>
      </ul>
    </InfoPage>
  );
}
