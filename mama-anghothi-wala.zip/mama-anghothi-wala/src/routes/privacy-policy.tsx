import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";

export const Route = createFileRoute("/privacy-policy")({
  head: infoHead("Privacy Policy", "What information Mama Anghothi Wala collects and how it's used."),
  component: () => (
    <InfoPage kicker="your data" title="Privacy policy">
      <h2>What we collect</h2>
      <p>Only what we need to fulfil your order: name, mobile number, optional email, and your delivery address (for home delivery).</p>
      <h2>Payments</h2>
      <p>Payments are handled on our payment provider's secure page. <strong>We never see or store your card number or CVV.</strong> We keep only the payment status and transaction reference.</p>
      <h2>How we use it</h2>
      <ul>
        <li>To prepare, deliver or hand over your order and contact you about it.</li>
        <li>To calculate the delivery charge, your address is sent to a mapping service to measure road distance.</li>
        <li>We don't sell your information.</li>
      </ul>
      <h2>Your cart</h2>
      <p>Your shopping bag is saved in your own browser so it survives a page refresh.</p>
      <h2>Contact</h2>
      <p>To ask about or delete your information, contact us via the contact page.</p>
    </InfoPage>
  ),
});
