import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Minus, Plus, ShoppingBag, Store, Truck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ProductGrid } from "@/components/shop/ProductCard";
import { productQuery } from "@/lib/queries";
import { useCart } from "@/lib/cart";
import { imgUrl, rs } from "@/lib/format";
import { totalStock } from "@/lib/catalog.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/product/$slug")({
  loader: async ({ context, params }) => {
    const d = await context.queryClient.ensureQueryData(productQuery(params.slug));
    if (!d) throw notFound();
    return { name: d.product.name, description: d.product.description.slice(0, 155) };
  },
  head: ({ loaderData }) => {
    const t = loaderData ? `${loaderData.name} — Mama Anghothi Wala` : "Product unavailable";
    return {
      meta: [
        { title: t },
        { name: "description", content: loaderData?.description ?? "Artificial jewellery by Mama Anghothi Wala." },
        { property: "og:title", content: t },
        { property: "og:description", content: loaderData?.description ?? "" },
        { property: "og:type", content: "product" },
        ...(loaderData ? [] : [{ name: "robots", content: "noindex" }]),
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { data } = useSuspenseQuery(productQuery(slug));
  const { add, items } = useCart();
  const p = data!.product;
  const [imgIdx, setImgIdx] = useState(0);
  const [variantId, setVariantId] = useState<string | null>(null);
  const [qty, setQty] = useState(1);

  const variants = p.product_variants;
  const variant = variants.find((v) => v.id === variantId) ?? null;
  const needsVariant = variants.length > 0;
  const stock = needsVariant ? (variant?.stock ?? totalStock(p)) : p.stock;
  const price = p.price + (variant?.price_adjustment ?? 0);
  const inCart = items.find((i) => i.productId === p.id && i.variantId === (variant?.id ?? null))?.quantity ?? 0;
  const canAdd = stock > 0 && (!needsVariant || variant) && qty + inCart <= stock;
  const off = p.compare_at_price && p.compare_at_price > p.price ? Math.round((1 - p.price / p.compare_at_price) * 100) : 0;
  const images = p.product_images.length ? p.product_images : [{ url: "", alt: p.name, sort_order: 0 }];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    sku: p.sku,
    description: p.description,
    category: p.category?.name,
    offers: {
      "@type": "Offer",
      priceCurrency: "PKR",
      price: p.price,
      availability: totalStock(p) > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className="container-shop py-8 md:py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
      <nav className="mb-6 text-sm text-muted-foreground" aria-label="Breadcrumb">
        <Link to="/shop" className="hover:text-primary">Shop</Link>
        {p.category && (
          <> / <Link to="/category/$slug" params={{ slug: p.category.slug }} className="hover:text-primary">{p.category.name}</Link></>
        )}
      </nav>

      <div className="grid gap-8 md:grid-cols-2 lg:gap-14">
        <div>
          <div className="relative aspect-square overflow-hidden rounded-[2rem] bg-muted">
            <img src={imgUrl(images[imgIdx]?.url)} alt={images[imgIdx]?.alt ?? p.name} width={900} height={900} className="size-full object-cover" />
            {p.is_sample && <span className="sticker absolute left-4 top-4 bg-foreground/80 text-background">Sample listing</span>}
          </div>
          {images.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {images.map((im, i) => (
                <button
                  key={i}
                  onClick={() => setImgIdx(i)}
                  aria-label={`Show image ${i + 1}`}
                  aria-pressed={i === imgIdx}
                  className={cn("size-20 shrink-0 overflow-hidden rounded-2xl border-2", i === imgIdx ? "border-primary" : "border-transparent")}
                >
                  <img src={imgUrl(im.url)} alt="" loading="lazy" className="size-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="flex flex-wrap gap-2">
            {p.is_new_arrival && <span className="sticker bg-gold text-gold-foreground">New drop</span>}
            {off > 0 && <span className="sticker bg-primary text-primary-foreground">-{off}% off</span>}
          </div>
          <h1 className="mt-3 font-display text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">{p.name}</h1>
          <p className="mt-1 text-sm text-muted-foreground">SKU: {p.sku}{p.subcategory ? ` · ${p.subcategory}` : ""}</p>
          <div className="mt-5 flex items-baseline gap-3">
            <span className="font-display text-4xl font-extrabold text-primary">{rs(price)}</span>
            {off > 0 && !variant?.price_adjustment && <span className="text-lg text-muted-foreground line-through">{rs(p.compare_at_price!)}</span>}
          </div>
          <p className={cn("mt-2 text-sm font-semibold", stock === 0 ? "text-destructive" : stock <= 3 ? "text-primary" : "text-success")}>
            {needsVariant && !variant ? "Choose an option to see stock" : stock === 0 ? "Out of stock" : stock <= 3 ? `Hurry — only ${stock} left` : "In stock"}
          </p>

          {needsVariant && (
            <fieldset className="mt-6">
              <legend className="mb-2 text-sm font-semibold">Choose option</legend>
              <div className="flex flex-wrap gap-2">
                {variants.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    disabled={v.stock === 0}
                    onClick={() => { setVariantId(v.id); setQty(1); }}
                    aria-pressed={variantId === v.id}
                    className={cn(
                      "min-w-14 rounded-full border-2 px-4 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-40 disabled:line-through",
                      variantId === v.id ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary",
                    )}
                  >
                    {v.label}
                    {v.price_adjustment ? ` (+${rs(v.price_adjustment)})` : ""}
                  </button>
                ))}
              </div>
            </fieldset>
          )}
          {p.colours.length > 0 && <p className="mt-4 text-sm"><span className="font-semibold">Colour:</span> {p.colours.join(", ")}</p>}

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-full border-2 border-border">
              <button className="grid size-11 place-items-center" aria-label="Decrease quantity" onClick={() => setQty((q) => Math.max(1, q - 1))}><Minus className="size-4" /></button>
              <span className="w-8 text-center font-semibold" aria-live="polite">{qty}</span>
              <button className="grid size-11 place-items-center" aria-label="Increase quantity" onClick={() => setQty((q) => Math.min(Math.max(1, stock - inCart), q + 1))}><Plus className="size-4" /></button>
            </div>
            <Button
              size="lg"
              variant="pop"
              className="flex-1"
              disabled={!canAdd}
              onClick={() => {
                add({
                  productId: p.id,
                  variantId: variant?.id ?? null,
                  slug: p.slug,
                  name: p.name,
                  variantLabel: variant?.label ?? null,
                  image: p.product_images[0]?.url ?? null,
                  unitPrice: price,
                  quantity: qty,
                  maxStock: stock,
                });
                toast.success("Added to bag ✨", { description: `${qty} × ${p.name}` });
              }}
            >
              <ShoppingBag /> {stock === 0 ? "Sold out" : needsVariant && !variant ? "Choose an option" : "Add to bag"}
            </Button>
          </div>
          {inCart > 0 && <p className="mt-2 text-sm text-muted-foreground">{inCart} already in your bag · <Link to="/cart" className="text-primary underline">View bag</Link></p>}

          <div className="mt-8 whitespace-pre-line leading-relaxed text-muted-foreground">{p.description}</div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <div className="flex gap-3 rounded-2xl bg-secondary/70 p-4 text-sm"><Truck className="size-5 shrink-0 text-primary" /><span>Home delivery in Karachi, fee by road distance</span></div>
            <div className="flex gap-3 rounded-2xl bg-secondary/70 p-4 text-sm"><Store className="size-5 shrink-0 text-primary" /><span>Free pickup at Bolton Market</span></div>
          </div>
        </div>
      </div>

      {data!.related.length > 0 && (
        <section className="mt-20">
          <h2 className="mb-6 font-display text-3xl font-extrabold">You might also like</h2>
          <ProductGrid items={data!.related} />
        </section>
      )}
    </div>
  );
}
