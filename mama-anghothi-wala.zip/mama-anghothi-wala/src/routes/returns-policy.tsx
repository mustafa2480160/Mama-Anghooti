import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";

export const Route = createFileRoute("/returns-policy")({
  head: infoHead("Returns & Refunds", "How returns, exchanges and refunds work at Mama Anghothi Wala."),
  component: () => (
    <InfoPage kicker="the fine print" title="Returns & refunds">
      <h2>Damaged or wrong item</h2>
      <p>If your item arrives damaged or isn't what you ordered, contact us within <strong>48 hours</strong> of receiving it with your order number and photos. We'll arrange a replacement or refund.</p>
      <h2>Change of mind</h2>
      <p>For hygiene reasons, earrings and items that have been worn can't be returned. Other unworn items in original packaging may be exchanged within 3 days — please contact us first.</p>
      <h2>Refunds</h2>
      <ul>
        <li>Approved refunds go back to the original online payment method through our payment provider.</li>
        <li>Delivery charges are refunded only if the mistake was ours.</li>
        <li>If an order can't be fulfilled (for example, an item sold out after payment), we refund the full amount.</li>
      </ul>
      <h2>Cancelled or unpaid orders</h2>
      <p>Orders that aren't paid within the payment window are cancelled automatically and nothing is charged.</p>
    </InfoPage>
  ),
});
