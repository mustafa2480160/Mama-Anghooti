import { createFileRoute } from "@tanstack/react-router";
import { Listing, listSearchSchema } from "@/components/shop/Listing";

export const Route = createFileRoute("/search")({
  validateSearch: listSearchSchema,
  head: () => ({
    meta: [
      { title: "Search — Mama Anghothi Wala" },
      { name: "description", content: "Search our artificial jewellery collection." },
      { property: "og:title", content: "Search — Mama Anghothi Wala" },
      { property: "og:description", content: "Find rings, chains, bracelets and more." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const search = Route.useSearch();
  return (
    <Listing
      title={search.q ? `"${search.q}"` : "Search"}
      kicker={search.q ? "results for" : "find your next fave"}
      search={search}
      showSearchBox
    />
  );
}
