import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";
import { storeInfoQuery } from "@/lib/queries";
import { deliveryFee } from "@/lib/delivery";
import { rs } from "@/lib/format";

export const Route = createFileRoute("/shipping-policy")({
  head: infoHead("Shipping & Delivery", "Delivery charges, areas and timelines for Mama Anghothi Wala orders in Karachi."),
  loader: ({ context }) => context.queryClient.ensureQueryData(storeInfoQuery),
  component: Page,
});

function Page() {
  const { data } = useSuspenseQuery(storeInfoQuery);
  const s = data.settings;
  const rows = [5, 10, 15, 20, 25, 30, 35, 40];
  return (
    <InfoPage kicker="delivery info" title="Shipping & delivery">
      <p>We deliver across Karachi. You can pay <strong>cash on delivery</strong> or online at checkout.</p>
      <h2>How the delivery charge works</h2>
      <p>
        Your charge is based on the <strong>road distance</strong> from our store ({s.address}, {s.city}) to your address. The first {Number(s.base_km)} km cost{" "}
        <strong>{rs(s.base_fee)}</strong>, then <strong>+{rs(s.step_fee)}</strong> for every extra {Number(s.step_km)} km (or part of it).
      </p>
      <div className="not-prose my-6 overflow-hidden rounded-2xl border">
        <table className="w-full text-sm">
          <thead className="bg-secondary text-left"><tr><th className="p-3">Distance (up to)</th><th className="p-3">Delivery charge</th></tr></thead>
          <tbody>
            {rows.map((km) => (
              <tr key={km} className="border-t"><td className="p-3">{km} km</td><td className="p-3 font-semibold">{rs(deliveryFee(km, s))}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <p>The exact charge is calculated at checkout and shown to you before you pay.</p>
      {s.max_radius_km != null && <p>We currently deliver up to <strong>{Number(s.max_radius_km)} km</strong> from the store. Further addresses can use store pickup.</p>}
      <h2>If we can't find your address</h2>
      <p>Please add more detail (house number, street, block, area). You can also message us on WhatsApp{s.whatsapp ? ` (${s.phone_primary})` : ""} or choose free store pickup.</p>
      <h2>Delivery time</h2>
      <p>We'll prepare and dispatch your order after payment is verified. Delivery times vary by area and order volume — contact us for an estimate.</p>
      <h2>Prefer to collect?</h2>
      <p>Store pickup is free. See our <Link to="/pickup-policy">pickup policy</Link>.</p>
    </InfoPage>
  );
}
