import { createFileRoute } from "@tanstack/react-router";
import { Listing, listSearchSchema } from "@/components/shop/Listing";

export const Route = createFileRoute("/shop")({
  validateSearch: listSearchSchema,
  head: () => ({
    meta: [
      { title: "Shop All Jewellery — Mama Anghothi Wala" },
      { name: "description", content: "Browse every ring, chain, bracelet, necklace, band and accessory. Prices in PKR." },
      { property: "og:title", content: "Shop All Jewellery — Mama Anghothi Wala" },
      { property: "og:description", content: "Browse all artificial and fashion jewellery." },
    ],
  }),
  component: () => <Listing title="Shop all" kicker="the whole collection" search={Route.useSearch()} />,
});
