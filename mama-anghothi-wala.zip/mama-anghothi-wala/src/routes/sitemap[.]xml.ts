import { createFileRoute } from "@tanstack/react-router";

const STATIC = [
  "/", "/shop", "/about", "/contact", "/faq", "/track-order", "/shipping-policy",
  "/pickup-policy", "/returns-policy", "/privacy-policy", "/terms",
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const origin = new URL(request.url).origin;
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const [{ data: cats }, { data: prods }] = await Promise.all([
          supabaseAdmin.from("categories").select("slug").eq("is_active", true),
          supabaseAdmin.from("products").select("slug, updated_at").eq("is_active", true).limit(5000),
        ]);
        const urls = [
          ...STATIC.map((p) => `<url><loc>${origin}${p}</loc></url>`),
          ...(cats ?? []).map((c) => `<url><loc>${origin}/category/${c.slug}</loc></url>`),
          ...(prods ?? []).map(
            (p) => `<url><loc>${origin}/product/${p.slug}</loc><lastmod>${p.updated_at.slice(0, 10)}</lastmod></url>`,
          ),
        ];
        return new Response(
          `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.join("")}</urlset>`,
          { headers: { "content-type": "application/xml", "cache-control": "public, max-age=3600" } },
        );
      },
    },
  },
});
