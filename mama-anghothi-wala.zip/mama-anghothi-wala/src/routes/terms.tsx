import { createFileRoute } from "@tanstack/react-router";
import { InfoPage, infoHead } from "@/components/shop/InfoPage";

export const Route = createFileRoute("/terms")({
  head: infoHead("Terms & Conditions", "Terms for shopping with Mama Anghothi Wala."),
  component: () => (
    <InfoPage kicker="the rules" title="Terms & conditions">
      <ul>
        <li>All products are artificial / fashion jewellery, not precious metals or real gemstones.</li>
        <li>Prices are in Pakistani Rupees (PKR) and may change; the price confirmed at checkout applies.</li>
        <li>Home delivery orders can be paid by cash on delivery or online. Store pickup orders must be paid online in full, and are confirmed only after payment is verified; cash at pickup is not accepted.</li>
        <li>Unpaid orders are held for a limited time and then cancelled automatically.</li>
        <li>Delivery charges are calculated by road distance and shown before payment.</li>
        <li>Product photos are shown as accurately as possible; slight colour differences may occur between screens.</li>
        <li>Returns and refunds follow our returns policy.</li>
      </ul>
    </InfoPage>
  ),
});
