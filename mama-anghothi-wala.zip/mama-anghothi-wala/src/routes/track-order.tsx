import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Loader2, PackageSearch } from "lucide-react";
import { Button } from "@/components/ui/button";
import { lookupOrder } from "@/lib/shop.functions";

export const Route = createFileRoute("/track-order")({
  head: () => ({
    meta: [
      { title: "Track Your Order — Mama Anghothi Wala" },
      { name: "description", content: "Look up your order status using your order number and mobile number." },
      { property: "og:title", content: "Track Your Order — Mama Anghothi Wala" },
      { property: "og:description", content: "Check your order status." },
    ],
  }),
  component: Track,
});

function Track() {
  const lookup = useServerFn(lookupOrder);
  const navigate = useNavigate();
  const [num, setNum] = useState("");
  const [phone, setPhone] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (!/^(\+92|0092|0)?3\d{9}$/.test(phone.replace(/[\s-]/g, ""))) return setErr("Enter the mobile number used at checkout, e.g. 03001234567");
    if (num.trim().length < 5) return setErr("Enter your order number, e.g. MAW-2611-1001");
    setBusy(true);
    try {
      const r = await lookup({ data: { orderNumber: num.trim(), phone: phone.replace(/[\s-]/g, "") } });
      if (r) navigate({ to: "/order/$token", params: { token: r.token } });
      else setErr("No order matches that order number and mobile number.");
    } catch {
      setErr("Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  };
  const input = "mt-1 h-12 w-full rounded-2xl border border-input bg-card px-4 outline-none focus:border-primary";
  return (
    <div className="container-shop max-w-xl py-14">
      <PackageSearch className="size-10 text-primary" />
      <h1 className="mt-3 font-display text-4xl font-extrabold sm:text-5xl">Track your order</h1>
      <p className="mt-2 text-muted-foreground">Enter your order number and the mobile number you used at checkout.</p>
      <form onSubmit={submit} className="mt-8 space-y-4 rounded-3xl border bg-card p-6" noValidate>
        <label className="block"><span className="text-sm font-medium">Order number</span>
          <input className={input} placeholder="MAW-2611-1001" value={num} onChange={(e) => setNum(e.target.value)} /></label>
        <label className="block"><span className="text-sm font-medium">Mobile number</span>
          <input className={input} type="tel" placeholder="03001234567" value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
        {err && <p className="text-sm text-destructive" role="alert">{err}</p>}
        <Button type="submit" variant="pop" size="lg" className="w-full" disabled={busy}>{busy && <Loader2 className="animate-spin" />} Find my order</Button>
      </form>
    </div>
  );
}
