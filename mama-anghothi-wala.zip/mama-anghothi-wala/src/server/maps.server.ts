// Road distance via Google Routes API (through the Lovable connector gateway). Server-only.
const GATEWAY = "https://connector-gateway.lovable.dev/google_maps";

export type DistanceResult =
  | { ok: true; km: number }
  | { ok: false; reason: "not_configured" | "not_found" | "error"; message: string };

export async function roadDistanceKm(origin: string, destination: string): Promise<DistanceResult> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey) {
    return { ok: false, reason: "not_configured", message: "Distance service is not configured." };
  }
  try {
    const res = await fetch(`${GATEWAY}/routes/directions/v2:computeRoutes`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": mapsKey,
        "Content-Type": "application/json",
        "X-Goog-FieldMask": "routes.distanceMeters",
      },
      body: JSON.stringify({
        origin: { address: origin },
        destination: { address: destination },
        travelMode: "DRIVE",
        regionCode: "PK",
        units: "METRIC",
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Routes API failed [${res.status}]: ${body.slice(0, 500)}`);
      if (res.status === 400 || res.status === 404) {
        return { ok: false, reason: "not_found", message: "We couldn't find that address." };
      }
      return { ok: false, reason: "error", message: "Distance service is temporarily unavailable." };
    }
    const data = (await res.json()) as { routes?: { distanceMeters?: number }[] };
    const route = data.routes?.[0];
    if (!route) return { ok: false, reason: "not_found", message: "No road route found to that address." };
    return { ok: true, km: (route.distanceMeters ?? 0) / 1000 };
  } catch (e) {
    console.error("Routes API error", e);
    return { ok: false, reason: "error", message: "Distance service is temporarily unavailable." };
  }
}
