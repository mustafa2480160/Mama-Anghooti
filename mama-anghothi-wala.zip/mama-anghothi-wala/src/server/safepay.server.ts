// Safepay hosted checkout integration. Server-only.
// NOT production-verified until SAFEPAY_* secrets are added and a sandbox payment is completed.

export interface SafepayConfig {
  env: "sandbox" | "production";
  base: string;
  apiKey: string;
  secretKey: string;
  webhookSecret: string | null;
}

export function safepayConfig(): SafepayConfig | null {
  const apiKey = process.env["SAFEPAY_API_KEY"];
  const secretKey = process.env["SAFEPAY_SECRET_KEY"];
  if (!apiKey || !secretKey) return null;
  const env = process.env["SAFEPAY_ENV"] === "production" ? "production" : "sandbox";
  return {
    env,
    base: env === "production" ? "https://api.getsafepay.com" : "https://sandbox.api.getsafepay.com",
    apiKey,
    secretKey,
    webhookSecret: process.env["SAFEPAY_WEBHOOK_SECRET"] ?? null,
  };
}

/** Creates a payment tracker + time-based token and returns the hosted checkout URL. */
export async function createCheckoutSession(
  cfg: SafepayConfig,
  opts: { amountRs: number; orderNumber: string; redirectUrl: string; cancelUrl: string },
): Promise<{ tracker: string; url: string }> {
  const trackerRes = await fetch(`${cfg.base}/order/payments/v3/`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-SFPY-MERCHANT-SECRET": cfg.secretKey },
    body: JSON.stringify({
      merchant_api_key: cfg.apiKey,
      intent: "CYBERSOURCE",
      mode: "payment",
      currency: "PKR",
      amount: Math.round(opts.amountRs * 100), // smallest unit (paisa)
      metadata: { order_id: opts.orderNumber },
    }),
  });
  if (!trackerRes.ok) {
    const t = await trackerRes.text();
    console.error(`Safepay tracker failed [${trackerRes.status}]: ${t.slice(0, 500)}`);
    throw new Error("PAYMENT_GATEWAY_ERROR");
  }
  const trackerJson = (await trackerRes.json()) as { data?: { tracker?: { token?: string } } };
  const tracker = trackerJson.data?.tracker?.token;
  if (!tracker) throw new Error("PAYMENT_GATEWAY_ERROR");

  const tbtRes = await fetch(`${cfg.base}/client/passport/v1/token`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-SFPY-MERCHANT-SECRET": cfg.secretKey },
  });
  if (!tbtRes.ok) {
    console.error(`Safepay tbt failed [${tbtRes.status}]`);
    throw new Error("PAYMENT_GATEWAY_ERROR");
  }
  const tbt = ((await tbtRes.json()) as { data?: string }).data;
  if (!tbt) throw new Error("PAYMENT_GATEWAY_ERROR");

  const q = new URLSearchParams({
    environment: cfg.env,
    tracker,
    tbt,
    source: "hosted",
    order_id: opts.orderNumber,
    redirect_url: opts.redirectUrl,
    cancel_url: opts.cancelUrl,
  });
  return { tracker, url: `${cfg.base}/embedded/?${q.toString()}` };
}

export type TrackerOutcome =
  | { state: "paid"; amountPaisa: number | null; reference: string | null }
  | { state: "pending" | "failed" | "unknown"; raw?: string | undefined };

/** Ask Safepay directly (server-to-server) for the tracker's state. Source of truth for payment. */
export async function fetchTrackerOutcome(cfg: SafepayConfig, tracker: string): Promise<TrackerOutcome> {
  const res = await fetch(`${cfg.base}/reporter/api/v1/payments/${encodeURIComponent(tracker)}`, {
    headers: { "X-SFPY-MERCHANT-SECRET": cfg.secretKey },
  });
  if (!res.ok) {
    console.error(`Safepay reporter failed [${res.status}]`);
    return { state: "unknown" };
  }
  const json = (await res.json()) as {
    data?: {
      tracker?: { state?: string; purchase_totals?: { quote_amount?: { amount?: number } } };
      state?: string;
      reference?: string;
    };
  };
  const state = json.data?.tracker?.state ?? json.data?.state;
  if (state === "TRACKER_ENDED") {
    return {
      state: "paid",
      amountPaisa: json.data?.tracker?.purchase_totals?.quote_amount?.amount ?? null,
      reference: json.data?.reference ?? null,
    };
  }
  if (state === "TRACKER_STARTED" || state === "TRACKER_AUTHORIZED" || state === "TRACKER_PENDING") {
    return { state: "pending" };
  }
  if (state === "TRACKER_FAILED" || state === "TRACKER_CANCELLED") return { state: "failed" };
  return { state: "unknown", raw: state };
}

async function hmacHex(algo: "SHA-256" | "SHA-512", key: string, message: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(key), { name: "HMAC", hash: algo }, false, [
    "sign",
  ]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(message));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export async function verifyWebhookSignature(secret: string, rawBody: string, signature: string | null) {
  if (!signature) return false;
  let dataPart = rawBody;
  try {
    const parsed = JSON.parse(rawBody);
    if (parsed?.data) dataPart = JSON.stringify(parsed.data);
  } catch {
    return false;
  }
  const sig = signature.trim().toLowerCase();
  for (const candidate of [dataPart, rawBody]) {
    if (safeEqual(await hmacHex("SHA-512", secret, candidate), sig)) return true;
    if (safeEqual(await hmacHex("SHA-256", secret, candidate), sig)) return true;
  }
  return false;
}
