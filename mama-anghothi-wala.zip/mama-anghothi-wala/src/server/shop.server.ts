// Core server-side shop logic: pricing, delivery quotes, order creation, payment settlement.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { deliveryFee } from "@/lib/delivery";
import { roadDistanceKm } from "./maps.server";
import { createCheckoutSession, fetchTrackerOutcome, safepayConfig } from "./safepay.server";

export class UserError extends Error {}

export async function getSettings() {
  const { data, error } = await supabaseAdmin.from("store_settings").select("*").eq("id", 1).single();
  if (error || !data) throw new Error("Store settings missing");
  return data;
}

type Settings = Awaited<ReturnType<typeof getSettings>>;

export interface DeliveryAddress {
  address: string;
  area: string;
  city: string;
}

export async function quoteDelivery(addr: DeliveryAddress, s?: Settings) {
  const settings = s ?? (await getSettings());
  if (!settings.delivery_enabled) throw new UserError("Home delivery is currently unavailable. Please choose store pickup.");
  const hay = `${addr.address} ${addr.area} ${addr.city}`.toLowerCase();
  const blocked = settings.unsupported_areas.find((a) => a.trim() && hay.includes(a.trim().toLowerCase()));
  if (blocked) throw new UserError(`Sorry, we don't deliver to ${blocked} yet. Store pickup is available.`);

  const origin =
    settings.latitude != null && settings.longitude != null
      ? `${settings.latitude},${settings.longitude}`
      : `${settings.address}, ${settings.city}, Pakistan`;
  const dest = `${addr.address}, ${addr.area}, ${addr.city}, Pakistan`;
  const r = await roadDistanceKm(origin, dest);
  if (!r.ok) {
    if (r.reason === "not_found")
      throw new UserError("We couldn't locate that address. Please add more detail (street, block, area) or contact us on WhatsApp.");
    throw new UserError("We can't calculate delivery right now. Please try again shortly, choose pickup, or message us on WhatsApp.");
  }
  if (settings.max_radius_km != null && r.km > Number(settings.max_radius_km)) {
    throw new UserError(
      `This address is ${r.km.toFixed(1)} km away — outside our ${settings.max_radius_km} km delivery area. Store pickup is available.`,
    );
  }
  const km = Math.round(r.km * 10) / 10;
  return { distanceKm: km, fee: deliveryFee(r.km, settings) };
}

export interface CartLine {
  productId: string;
  variantId: string | null;
  quantity: number;
}

/** Re-price a cart from the database. Never trusts browser prices. */
export async function priceCart(lines: CartLine[]) {
  const ids = [...new Set(lines.map((l) => l.productId))];
  const { data: products, error } = await supabaseAdmin
    .from("products")
    .select("id, sku, name, slug, price, stock, is_active, product_images(url, sort_order), product_variants(id, label, price_adjustment, stock, is_active)")
    .in("id", ids);
  if (error) throw error;

  const priced = lines.map((l) => {
    const p = products?.find((x) => x.id === l.productId);
    if (!p || !p.is_active) return { ...l, ok: false as const, problem: "This item is no longer available." };
    const activeVariants = p.product_variants.filter((v) => v.is_active);
    let unit = p.price;
    let stock = p.stock;
    let label: string | null = null;
    if (activeVariants.length > 0) {
      const v = activeVariants.find((x) => x.id === l.variantId);
      if (!v) return { ...l, ok: false as const, problem: "Please choose an option for this item." };
      unit = p.price + v.price_adjustment;
      stock = v.stock;
      label = v.label;
    } else if (l.variantId) {
      return { ...l, ok: false as const, problem: "This option is no longer available." };
    }
    const img = [...p.product_images].sort((a, b) => a.sort_order - b.sort_order)[0]?.url ?? null;
    return {
      ...l,
      ok: true as const,
      name: p.name,
      slug: p.slug,
      sku: p.sku,
      variantLabel: label,
      image: img,
      unitPrice: unit,
      stock,
      problem: stock < l.quantity ? (stock === 0 ? "Out of stock." : `Only ${stock} left.`) : null,
    };
  });
  return priced;
}

export interface CheckoutInput {
  idempotencyKey: string;
  items: CartLine[];
  fulfilment: "delivery" | "pickup";
  paymentMethod: "online" | "cod";
  customer: {
    name: string;
    phone: string;
    email?: string;
    address?: string;
    city?: string;
    area?: string;
    landmark?: string;
    notes?: string;
  };
  origin: string;
}

export async function createOrderAndPayment(input: CheckoutInput) {
  await supabaseAdmin.rpc("expire_stale_orders");

  // Duplicate submission: return the existing order instead of creating another.
  const { data: existing } = await supabaseAdmin
    .from("orders")
    .select("id, access_token, payment_status, status, payment_method")
    .eq("idempotency_key", input.idempotencyKey)
    .maybeSingle();
  if (existing) {
    if (existing.payment_method === "cod") return { token: existing.access_token, paymentUrl: null, alreadyPaid: false, cod: true };
    if (existing.payment_status === "paid") return { token: existing.access_token, paymentUrl: null, alreadyPaid: true };
    const pay = await startPayment(existing.id, input.origin);
    return { token: existing.access_token, ...pay, alreadyPaid: false };
  }

  const settings = await getSettings();
  if (input.fulfilment === "pickup" && !settings.pickup_enabled) throw new UserError("Store pickup is currently unavailable.");
  if (input.paymentMethod === "cod" && input.fulfilment !== "delivery") throw new UserError("Pickup orders must be paid online.");
  if (input.paymentMethod === "cod" && !settings.cod_enabled) throw new UserError("Cash on delivery is currently unavailable. Please pay online.");

  const priced = await priceCart(input.items);
  const bad = priced.find((p) => !p.ok || p.problem);
  if (bad) throw new UserError(`Please review your cart: ${bad.ok ? `${bad.name} — ${bad.problem}` : bad.problem}`);

  const subtotal = priced.reduce((s, p) => s + (p.ok ? p.unitPrice * p.quantity : 0), 0);
  let fee = 0;
  let distance: number | null = null;
  if (input.fulfilment === "delivery") {
    const q = await quoteDelivery(
      { address: input.customer.address ?? "", area: input.customer.area ?? "", city: input.customer.city ?? "" },
      settings,
    );
    fee = q.fee;
    distance = q.distanceKm;
  }

  const c = input.customer;
  const isDelivery = input.fulfilment === "delivery";
  const { data, error } = await supabaseAdmin.rpc("create_order_reserving_stock", {
    _order: {
      idempotency_key: input.idempotencyKey,
      fulfilment: input.fulfilment,
      customer_name: c.name,
      phone: c.phone,
      email: c.email ?? "",
      address: isDelivery ? c.address : "",
      city: isDelivery ? c.city : "",
      area: isDelivery ? c.area : "",
      landmark: isDelivery ? c.landmark ?? "" : "",
      notes: c.notes ?? "",
      distance_km: distance == null ? "" : String(distance),
      delivery_fee: fee,
      subtotal,
      total: subtotal + fee,
      payment_window_minutes: settings.payment_window_minutes,
    },
    _items: priced.map((p) =>
      p.ok
        ? {
            product_id: p.productId,
            variant_id: p.variantId,
            product_name: p.name,
            sku: p.sku,
            variant_label: p.variantLabel ?? "",
            image_url: p.image ?? "",
            unit_price: p.unitPrice,
            quantity: p.quantity,
          }
        : null,
    ),
  });
  if (error) {
    const m = error.message.match(/OUT_OF_STOCK:(.*)/);
    if (m) throw new UserError(`Sorry, "${m[1]}" just sold out or has less stock than requested.`);
    console.error("create order failed", error);
    throw new Error("ORDER_FAILED");
  }
  const row = data?.[0];
  if (!row) throw new Error("ORDER_FAILED");
  if (input.paymentMethod === "cod") {
    // COD: confirm immediately and keep stock reserved; staff record the cash when delivered.
    const { error: codErr } = await supabaseAdmin.from("orders").update({
      payment_method: "cod", status: "confirmed",
      reservation_expires_at: new Date(Date.now() + 3650 * 864e5).toISOString(),
    }).eq("id", row.order_id);
    if (codErr) { console.error("cod update failed", codErr); throw new Error("ORDER_FAILED"); }
    return { token: row.access_token, paymentUrl: null, alreadyPaid: false, cod: true };
  }
  const pay = await startPayment(row.order_id, input.origin);
  return { token: row.access_token, ...pay, alreadyPaid: false };
}

/** Create a Safepay session for an unpaid, unexpired order. */
export async function startPayment(orderId: string, origin: string) {
  const { data: order } = await supabaseAdmin.from("orders").select("*").eq("id", orderId).single();
  if (!order) throw new Error("ORDER_NOT_FOUND");
  if (order.payment_status === "paid") return { paymentUrl: null, paymentUnavailable: false };
  if (order.status === "expired" || order.status === "cancelled" || new Date(order.reservation_expires_at) < new Date()) {
    throw new UserError("This order's payment window has expired. Please place a new order.");
  }
  const cfg = safepayConfig();
  if (!cfg) return { paymentUrl: null, paymentUnavailable: true };

  const back = `${origin}/payment?order=${order.access_token}`;
  const session = await createCheckoutSession(cfg, {
    amountRs: order.total,
    orderNumber: order.order_number,
    redirectUrl: back,
    cancelUrl: `${back}&cancelled=1`,
  });
  await supabaseAdmin.from("payments").insert({
    order_id: order.id,
    environment: cfg.env,
    tracker: session.tracker,
    amount: order.total,
    status: "processing",
  });
  await supabaseAdmin.from("orders").update({ status: "payment_processing", payment_status: "processing" }).eq("id", order.id);
  return { paymentUrl: session.url, paymentUnavailable: false };
}

/** Verify with Safepay server-to-server and settle the order. Idempotent. */
export async function settlePayment(paymentId: string) {
  const cfg = safepayConfig();
  if (!cfg) return "not_configured";
  const { data: payment } = await supabaseAdmin.from("payments").select("*").eq("id", paymentId).single();
  if (!payment?.tracker) return "no_tracker";
  if (payment.status === "paid") return "already_paid";

  const outcome = await fetchTrackerOutcome(cfg, payment.tracker);
  if (outcome.state === "paid") {
    const { data: order } = await supabaseAdmin.from("orders").select("total").eq("id", payment.order_id).single();
    if (!order) return "no_order";
    if (outcome.amountPaisa != null && outcome.amountPaisa !== order.total * 100 && outcome.amountPaisa !== order.total) {
      console.error("Safepay amount mismatch", { paymentId, expected: order.total, got: outcome.amountPaisa });
      await supabaseAdmin.from("payment_events").insert({
        payment_id: paymentId,
        event_key: `mismatch:${paymentId}`,
        event_type: "amount_mismatch",
        source: "verification",
        payload: { expected: order.total, got: outcome.amountPaisa },
      });
      return "amount_mismatch";
    }
    const { data: result } = await supabaseAdmin.rpc("mark_order_paid", { _order_id: payment.order_id, _amount: order.total });
    await supabaseAdmin.from("payments").update({ status: "paid", reference: outcome.reference }).eq("id", paymentId);
    return result ?? "paid";
  }
  if (outcome.state === "failed") {
    await supabaseAdmin.from("payments").update({ status: "failed" }).eq("id", paymentId);
    await supabaseAdmin
      .from("orders")
      .update({ status: "pending_payment", payment_status: "failed" })
      .eq("id", payment.order_id)
      .neq("payment_status", "paid");
    return "failed";
  }
  return outcome.state;
}

export async function orderByToken(token: string) {
  const { data: order } = await supabaseAdmin
    .from("orders")
    .select(
      "id, order_number, status, payment_status, payment_method, fulfilment, customer_name, phone, email, address, city, area, landmark, notes, distance_km, delivery_fee, subtotal, total, reservation_expires_at, paid_at, created_at, order_items(product_name, sku, variant_label, image_url, unit_price, quantity, line_total)",
    )
    .eq("access_token", token)
    .maybeSingle();
  return order;
}
